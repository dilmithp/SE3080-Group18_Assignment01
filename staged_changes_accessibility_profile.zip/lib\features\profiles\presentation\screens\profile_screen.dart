import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import 'package:elderly_companion/core/routing/route_names.dart';
import 'package:elderly_companion/core/theme/app_dimens.dart';
import 'package:elderly_companion/core/widgets/app_button.dart';
import 'package:elderly_companion/core/widgets/app_card.dart';
import 'package:elderly_companion/core/widgets/app_status_icon.dart';
import 'package:elderly_companion/core/widgets/empty_view.dart';
import 'package:elderly_companion/core/widgets/error_view.dart';
import 'package:elderly_companion/core/widgets/loading_view.dart';
import 'package:elderly_companion/features/auth_trust/presentation/providers/auth_providers.dart';
import 'package:elderly_companion/features/auth_trust/presentation/widgets/trust_badge_chip.dart';
import 'package:elderly_companion/features/profiles/domain/entities/profile_completeness.dart';
import 'package:elderly_companion/features/profiles/domain/entities/user_profile.dart';
import 'package:elderly_companion/features/profiles/presentation/providers/profile_providers.dart';
import 'package:elderly_companion/features/profiles/presentation/widgets/emergency_contact_card.dart';

/// Owner: Perera (features/profiles). Shows the signed-in user's own
/// profile, or invites them to create one if [profileProvider] has nothing
/// yet.
class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Profile'),
        actions: [
          Semantics(
            label: 'Edit profile',
            button: true,
            child: IconButton(
              icon: const Icon(Icons.edit_outlined),
              tooltip: 'Edit profile',
              onPressed: () => context.push(RouteNames.editProfile),
            ),
          ),
        ],
      ),
      body: authState.when(
        loading: () => const LoadingView(),
        error: (error, _) => ErrorView(message: error.toString()),
        data: (user) {
          if (user == null) {
            return const EmptyView(
              icon: Icons.lock_outline,
              title: 'Sign in first',
              message: 'You need to be signed in to view your profile.',
            );
          }
          return _ProfileBody(userId: user.id);
        },
      ),
    );
  }
}

class _ProfileBody extends ConsumerWidget {
  const _ProfileBody({required this.userId});

  final String userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(profileProvider(userId));

    return profileAsync.when(
      loading: () => const LoadingView(),
      error: (error, _) => ErrorView(message: error.toString()),
      data: (profile) {
        if (profile == null) {
          return EmptyView(
            icon: Icons.person_outline,
            title: 'Your profile is empty',
            message: 'Add your name, interests and availability so '
                'companions and helpers can find you.',
            action: AppButton(
              label: 'Complete profile',
              icon: Icons.edit_outlined,
              onPressed: () => context.push(RouteNames.editProfile),
            ),
          );
        }
        return _ProfileView(profile: profile);
      },
    );
  }
}

class _ProfileView extends StatelessWidget {
  const _ProfileView({required this.profile});

  final UserProfile profile;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final completeness = ProfileCompleteness.of(profile);

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppSpacing.lg),
      child: Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: AppLayout.maxContentWidth),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Center(
                child: Column(
                  children: [
                    _Avatar(photoUrl: profile.photoUrl),
                    const SizedBox(height: AppSpacing.sm),
                    _TrustBadge(userId: profile.userId),
                    const SizedBox(height: AppSpacing.sm),
                    Semantics(
                      label: profile.displayName.isEmpty
                          ? 'No name set'
                          : 'Name: ${profile.displayName}',
                      child: Text(
                        profile.displayName.isEmpty
                            ? 'Add your name'
                            : profile.displayName,
                        style: theme.textTheme.headlineMedium,
                        textAlign: TextAlign.center,
                      ),
                    ),
                    if (profile.locality.isNotEmpty) ...[
                      const SizedBox(height: AppSpacing.xs),
                      Semantics(
                        label: 'Location: ${profile.locality}',
                        child: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              Icons.place_outlined,
                              size: 18,
                              color: theme.colorScheme.onSurfaceVariant,
                            ),
                            const SizedBox(width: AppSpacing.xs),
                            Text(
                              profile.locality,
                              style: theme.textTheme.bodyMedium?.copyWith(
                                color: theme.colorScheme.onSurfaceVariant,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: AppSpacing.lg),
              _CompletenessCard(completeness: completeness),
              const SizedBox(height: AppSpacing.md),
              EmergencyContactCard(profile: profile),
              if (profile.emergencyContactName?.trim().isNotEmpty == true ||
                  profile.emergencyContactPhone?.trim().isNotEmpty == true)
                const SizedBox(height: AppSpacing.md),
              if (profile.bio.isNotEmpty) ...[
                Semantics(
                  label: 'About: ${profile.bio}',
                  child: AppCard(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('About', style: theme.textTheme.titleLarge),
                        const SizedBox(height: AppSpacing.sm),
                        Text(profile.bio, style: theme.textTheme.bodyLarge),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
              ],
              if (profile.languagesSpoken.isNotEmpty) ...[
                _TagSection(title: 'Languages', tags: profile.languagesSpoken),
                const SizedBox(height: AppSpacing.md),
              ],
              if (profile.safetyPreferences.isNotEmpty) ...[
                _TagSection(
                  title: 'Safety preferences',
                  tags: profile.safetyPreferences,
                ),
                const SizedBox(height: AppSpacing.md),
              ],
              if (profile.skillsOffered.isNotEmpty) ...[
                _TagSection(title: 'Skills offered', tags: profile.skillsOffered),
                const SizedBox(height: AppSpacing.md),
              ],
              if (profile.helpNeeded.isNotEmpty) ...[
                _TagSection(title: 'Help needed', tags: profile.helpNeeded),
                const SizedBox(height: AppSpacing.md),
              ],
              if (profile.availabilityWindows.isNotEmpty) ...[
                AppCard(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text('Availability', style: theme.textTheme.titleLarge),
                      const SizedBox(height: AppSpacing.sm),
                      for (final window in profile.availabilityWindows)
                        Padding(
                          padding: const EdgeInsets.only(bottom: AppSpacing.xs),
                          child: Semantics(
                            label: 'Available on ${window.dayOfWeek} from '
                                '${window.startTime} to ${window.endTime}',
                            child: Row(
                              children: [
                                Icon(
                                  Icons.schedule_outlined,
                                  size: 18,
                                  color: theme.colorScheme.onSurfaceVariant,
                                ),
                                const SizedBox(width: AppSpacing.xs),
                                Text(
                                  '${window.dayOfWeek} ${window.startTime}–${window.endTime}',
                                  style: theme.textTheme.bodyMedium,
                                ),
                              ],
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
                const SizedBox(height: AppSpacing.md),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

/// Watches the signed-in user's own trust score and renders it as a
/// [TrustBadgeChip]. Most users have no `trust_scores` document yet (see
/// [TrustBadge]'s doc comment) — [AsyncValue.valueOrNull] folds both "still
/// loading" and "no document" to `null`, which [TrustBadgeChip] already
/// renders as the "New member" tier, so there is nothing extra to handle
/// here.
class _TrustBadge extends ConsumerWidget {
  const _TrustBadge({required this.userId});

  final String userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final trustScoreAsync = ref.watch(watchTrustScoreProvider(userId));
    return TrustBadgeChip(trustScore: trustScoreAsync.valueOrNull);
  }
}

class _Avatar extends StatelessWidget {
  const _Avatar({this.photoUrl});

  final String? photoUrl;

  @override
  Widget build(BuildContext context) {
    final hasPhoto = photoUrl != null && photoUrl!.isNotEmpty;
    return Semantics(
      label: hasPhoto ? 'Profile photo' : 'Profile photo: not set',
      image: true,
      child: hasPhoto
          ? CircleAvatar(
              radius: 48,
              backgroundImage: NetworkImage(photoUrl!),
            )
          : const AppStatusIcon(icon: Icons.person, size: 96),
    );
  }
}

class _CompletenessCard extends StatelessWidget {
  const _CompletenessCard({required this.completeness});

  final ProfileCompleteness completeness;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    if (completeness.isComplete) {
      return Semantics(
        label: 'Profile completeness: complete',
        child: AppCard(
          child: Row(
            children: [
              Icon(Icons.verified_outlined, color: theme.colorScheme.primary),
              const SizedBox(width: AppSpacing.sm),
              Expanded(
                child: Text(
                  'Your profile is complete',
                  style: theme.textTheme.titleMedium,
                ),
              ),
            ],
          ),
        ),
      );
    }

    return Semantics(
      label: 'Profile completeness: ${completeness.percent}%. '
          '${completeness.completedCount} of ${completeness.totalCount} sections complete. '
          'Missing: ${completeness.missing.take(4).join(", ")}',
      child: AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    'Profile ${completeness.percent}% complete',
                    style: theme.textTheme.titleLarge,
                  ),
                ),
                Text(
                  '${completeness.completedCount}/${completeness.totalCount}',
                  style: theme.textTheme.bodyMedium?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppSpacing.sm),
            Semantics(
              label: 'Progress bar: ${completeness.percent}% complete',
              value: '${completeness.percent}%',
              child: LinearProgressIndicator(
                value: completeness.fraction,
                minHeight: 8,
                borderRadius: BorderRadius.circular(AppRadius.pill),
              ),
            ),
            const SizedBox(height: AppSpacing.md),
            Text('Next steps', style: theme.textTheme.titleMedium),
            const SizedBox(height: AppSpacing.xs),
            for (final item in completeness.missing.take(4))
              Padding(
                padding: const EdgeInsets.only(bottom: AppSpacing.xs),
                child: Row(
                  children: [
                    Icon(
                      Icons.radio_button_unchecked,
                      size: 18,
                      color: theme.colorScheme.onSurfaceVariant,
                    ),
                    const SizedBox(width: AppSpacing.xs),
                    Expanded(child: Text(item, style: theme.textTheme.bodyMedium)),
                  ],
                ),
              ),
            if (completeness.missing.length > 4)
              Text(
                'and ${completeness.missing.length - 4} more',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onSurfaceVariant,
                ),
              ),
          ],
        ),
      ),
    );
  }
}

class _TagSection extends StatelessWidget {
  const _TagSection({required this.title, required this.tags});

  final String title;
  final List<String> tags;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Semantics(
      label: '$title: ${tags.join(", ")}',
      child: AppCard(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: theme.textTheme.titleLarge),
            const SizedBox(height: AppSpacing.sm),
            Wrap(
              spacing: AppSpacing.sm,
              runSpacing: AppSpacing.sm,
              children: [
                for (final tag in tags)
                  Semantics(
                    label: '$tag chip',
                    child: Chip(
                      label: Text(tag),
                      backgroundColor: theme.colorScheme.secondaryContainer,
                      labelStyle:
                          TextStyle(color: theme.colorScheme.onSecondaryContainer),
                      side: BorderSide.none,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
