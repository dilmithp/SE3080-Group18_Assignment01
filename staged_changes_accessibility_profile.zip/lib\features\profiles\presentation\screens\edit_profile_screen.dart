import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';

import 'package:elderly_companion/core/services/tts_provider.dart';
import 'package:elderly_companion/core/theme/accessibility/accessibility_controller.dart';
import 'package:elderly_companion/core/theme/app_dimens.dart';
import 'package:elderly_companion/core/utils/validators.dart';
import 'package:elderly_companion/core/widgets/app_button.dart';
import 'package:elderly_companion/core/widgets/app_status_icon.dart';
import 'package:elderly_companion/core/widgets/app_text_field.dart';
import 'package:elderly_companion/core/widgets/empty_view.dart';
import 'package:elderly_companion/core/widgets/error_view.dart';
import 'package:elderly_companion/core/widgets/loading_view.dart';
import 'package:elderly_companion/core/widgets/app_card.dart';
import 'package:elderly_companion/features/auth_trust/presentation/providers/auth_providers.dart';
import 'package:elderly_companion/features/profiles/domain/entities/accessibility_preferences.dart';
import 'package:elderly_companion/features/profiles/domain/entities/availability_window.dart';
import 'package:elderly_companion/features/profiles/domain/entities/geo_coordinates.dart';
import 'package:elderly_companion/features/profiles/domain/entities/safety_preference.dart';
import 'package:elderly_companion/features/profiles/domain/entities/user_profile.dart';
import 'package:elderly_companion/features/profiles/presentation/providers/profile_providers.dart';
import 'package:elderly_companion/features/profiles/presentation/widgets/location_picker.dart';

const _weekdays = [
  'Monday',
  'Tuesday',
  'Wednesday',
  'Thursday',
  'Friday',
  'Saturday',
  'Sunday',
];

/// Bio max length in characters; also enforced in firestore.rules.
const _bioMaxLength = 500;

/// Max length for display name and emergency contact name.
const _nameMaxLength = 100;

/// Max length for locality string.
const _localityMaxLength = 200;

/// Max characters per tag; also checked in firestore.rules.
const _tagMaxLength = 50;

/// Max number of tags per tag field; also checked in firestore.rules.
const _tagMaxCount = 20;

String _formatTimeOfDay(TimeOfDay time) =>
    '${time.hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')}';

/// Owner: Perera (features/profiles). Real form for creating/editing the
/// signed-in user's profile, wired to [GetProfileUseCase]'s live stream and
/// [UpdateProfileUseCase]. Of `accessibilityPrefs`, only `communicationNotes`
/// is editable here — `largeText`/`highContrast`/`simplifiedInterface` are
/// device-display settings owned by AccessibilitySettingsScreen (which
/// writes them through to the profile itself; see
/// AccessibilityProfileSync), so they pass through unchanged from here.
class EditProfileScreen extends ConsumerWidget {
  const EditProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final authState = ref.watch(authStateProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit profile'),
        // Let TalkBack/VoiceOver announce the edit profile screen.
      ),
      body: authState.when(
        loading: () => const LoadingView(),
        error: (error, _) => ErrorView(message: error.toString()),
        data: (user) {
          if (user == null) {
            return const EmptyView(
              icon: Icons.lock_outline,
              title: 'Sign in first',
              message: 'You need to be signed in to edit your profile.',
            );
          }
          return _EditProfileLoader(userId: user.id);
        },
      ),
    );
  }
}

class _EditProfileLoader extends ConsumerWidget {
  const _EditProfileLoader({required this.userId});

  final String userId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(profileProvider(userId));

    return profileAsync.when(
      loading: () => const LoadingView(),
      error: (error, _) => ErrorView(message: error.toString()),
      data: (profile) => _EditProfileForm(userId: userId, initial: profile),
    );
  }
}

class _EditProfileForm extends ConsumerStatefulWidget {
  const _EditProfileForm({required this.userId, required this.initial});

  final String userId;
  final UserProfile? initial;

  @override
  ConsumerState<_EditProfileForm> createState() => _EditProfileFormState();
}

class _EditProfileFormState extends ConsumerState<_EditProfileForm> {
  final _formKey = GlobalKey<FormState>();
  late final TextEditingController _nameController;
  late final TextEditingController _bioController;
  late final TextEditingController _localityController;
  late final TextEditingController _skillsController;
  late final TextEditingController _helpController;
  late final TextEditingController _languagesController;
  late Set<String> _safetySelection;
  late final TextEditingController _communicationNotesController;
  late final TextEditingController _emergencyContactNameController;
  late final TextEditingController _emergencyContactPhoneController;
  late List<AvailabilityWindow> _availabilityWindows;
  late GeoCoordinates _geoPoint;

  String? _photoUrl;
  bool _isSaving = false;
  bool _isUploadingPhoto = false;

  UserProfile get _base =>
      widget.initial ??
      UserProfile(
        userId: widget.userId,
        displayName: '',
        bio: '',
        locality: '',
        geoPoint: const GeoCoordinates(latitude: 0, longitude: 0),
        skillsOffered: const [],
        helpNeeded: const [],
        availabilityWindows: const [],
        accessibilityPrefs: const AccessibilityPreferences(
          largeText: false,
          highContrast: false,
          simplifiedInterface: false,
        ),
      );

  @override
  void initState() {
    super.initState();
    final base = _base;
    _nameController = TextEditingController(text: base.displayName);
    _bioController = TextEditingController(text: base.bio);
    _localityController = TextEditingController(text: base.locality);
    _skillsController = TextEditingController(text: base.skillsOffered.join(', '));
    _helpController = TextEditingController(text: base.helpNeeded.join(', '));
    _languagesController =
        TextEditingController(text: base.languagesSpoken.join(', '));
    _safetySelection = {...base.safetyPreferences};
    _communicationNotesController =
        TextEditingController(text: base.accessibilityPrefs.communicationNotes ?? '');
    _emergencyContactNameController =
        TextEditingController(text: base.emergencyContactName ?? '');
    _emergencyContactPhoneController =
        TextEditingController(text: base.emergencyContactPhone ?? '');
    _availabilityWindows = List.of(base.availabilityWindows);
    _geoPoint = base.geoPoint;
    _photoUrl = base.photoUrl;
  }

  @override
  void dispose() {
    _nameController.dispose();
    _bioController.dispose();
    _localityController.dispose();
    _skillsController.dispose();
    _languagesController.dispose();
    _helpController.dispose();
    _communicationNotesController.dispose();
    _emergencyContactNameController.dispose();
    _emergencyContactPhoneController.dispose();
    super.dispose();
  }

  List<String> _parseTags(String text) => text
      .split(',')
      .map((tag) => tag.trim())
      .where((tag) => tag.isNotEmpty)
      .toList();

  /// Speak a prompt via TTS when voice-guided prompts are enabled.
  void _speak(String text) {
    final accessibility = ref.read(accessibilityControllerProvider);
    ref.read(ttsServiceProvider).speak(
      text,
      voiceGuidedEnabled: accessibility.voiceGuidedPrompts,
    );
  }

  Future<void> _changePhoto() async {
    final messenger = ScaffoldMessenger.of(context);
    final accessibility = ref.read(accessibilityControllerProvider);
    // Data saver: use lower quality & smaller max dimensions.
    final quality = accessibility.dataSaver ? 50 : 85;
    final maxDim = accessibility.dataSaver ? 512 : 1024;

    final picked = await ImagePicker().pickImage(
      source: ImageSource.gallery,
      imageQuality: quality,
      maxWidth: maxDim.toDouble(),
      maxHeight: maxDim.toDouble(),
    );
    if (picked == null) return;

    setState(() => _isUploadingPhoto = true);
    try {
      final bytes = await picked.readAsBytes();
      final result = await ref.read(profileRepositoryProvider).uploadProfilePhoto(
            userId: widget.userId,
            bytes: bytes,
          );
      result.fold(
        (failure) => messenger
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text(failure.message))),
        (url) => setState(() => _photoUrl = url),
      );
    } finally {
      if (mounted) setState(() => _isUploadingPhoto = false);
    }
  }

  Future<void> _addAvailabilityWindow() async {
    final messenger = ScaffoldMessenger.of(context);
    var selectedDay = _weekdays.first;
    var startTime = const TimeOfDay(hour: 9, minute: 0);
    var endTime = const TimeOfDay(hour: 12, minute: 0);

    final added = await showModalBottomSheet<bool>(
      context: context,
      isScrollControlled: true,
      builder: (sheetContext) => StatefulBuilder(
        builder: (sheetContext, setSheetState) => Padding(
          padding: EdgeInsets.only(
            left: AppSpacing.lg,
            right: AppSpacing.lg,
            top: AppSpacing.lg,
            bottom: MediaQuery.of(sheetContext).viewInsets.bottom + AppSpacing.lg,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text('Add availability', style: Theme.of(sheetContext).textTheme.headlineMedium),
              const SizedBox(height: AppSpacing.lg),
              Semantics(
                label: 'Day of week picker',
                child: DropdownButtonFormField<String>(
                  initialValue: selectedDay,
                  decoration: const InputDecoration(labelText: 'Day'),
                  items: [
                    for (final day in _weekdays)
                      DropdownMenuItem(value: day, child: Text(day)),
                  ],
                  onChanged: (value) {
                    if (value != null) setSheetState(() => selectedDay = value);
                  },
                ),
              ),
              const SizedBox(height: AppSpacing.md),
              Row(
                children: [
                  Expanded(
                    child: Semantics(
                      label: 'From time: ${startTime.format(sheetContext)}',
                      button: true,
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: sheetContext,
                            initialTime: startTime,
                          );
                          if (picked != null) setSheetState(() => startTime = picked);
                        },
                        icon: const Icon(Icons.access_time),
                        label: Text('From ${startTime.format(sheetContext)}'),
                      ),
                    ),
                  ),
                  const SizedBox(width: AppSpacing.sm),
                  Expanded(
                    child: Semantics(
                      label: 'To time: ${endTime.format(sheetContext)}',
                      button: true,
                      child: OutlinedButton.icon(
                        onPressed: () async {
                          final picked = await showTimePicker(
                            context: sheetContext,
                            initialTime: endTime,
                          );
                          if (picked != null) setSheetState(() => endTime = picked);
                        },
                        icon: const Icon(Icons.access_time),
                        label: Text('To ${endTime.format(sheetContext)}'),
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppSpacing.lg),
              AppButton(
                label: 'Add',
                onPressed: () {
                  final start = _formatTimeOfDay(startTime);
                  final end = _formatTimeOfDay(endTime);
                  if (start.compareTo(end) >= 0) {
                    messenger
                      ..hideCurrentSnackBar()
                      ..showSnackBar(
                        const SnackBar(content: Text('End time must be after start time.')),
                      );
                    return;
                  }
                  setState(() {
                    _availabilityWindows.add(
                      AvailabilityWindow(
                        dayOfWeek: selectedDay,
                        startTime: start,
                        endTime: end,
                      ),
                    );
                  });
                  Navigator.of(sheetContext).pop(true);
                },
              ),
            ],
          ),
        ),
      ),
    );

    if (added ?? false) {
      _speak('Availability added.');
      messenger
        ..hideCurrentSnackBar()
        ..showSnackBar(const SnackBar(content: Text('Availability added.')));
    }
  }

  /// Removes the availability window at [index] and shows an Undo snackbar.
  void _removeAvailabilityWindow(int index) {
    final removed = _availabilityWindows[index];
    setState(() => _availabilityWindows.removeAt(index));

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Availability window removed: ${removed.dayOfWeek} '
          '${removed.startTime}–${removed.endTime}',
        ),
        action: SnackBarAction(
          label: 'Undo',
          onPressed: () => setState(() => _availabilityWindows.insert(index, removed)),
        ),
      ),
    );
  }

  Future<void> _save() async {
    if (!(_formKey.currentState?.validate() ?? false)) return;
    final messenger = ScaffoldMessenger.of(context);
    setState(() => _isSaving = true);
    try {
      final updated = _base.copyWith(
        displayName: _nameController.text.trim(),
        bio: _bioController.text.trim(),
        locality: _localityController.text.trim(),
        geoPoint: _geoPoint,
        skillsOffered: _parseTags(_skillsController.text),
        helpNeeded: _parseTags(_helpController.text),
        languagesSpoken: _parseTags(_languagesController.text),
        safetyPreferences: _safetySelection.toList(),
        availabilityWindows: _availabilityWindows,
        // Not `_base.accessibilityPrefs.copyWith(communicationNotes: ...)` —
        // that class's copyWith does `x ?? this.x`, so passing null to
        // clear a note would silently keep the old one. Rebuilding the
        // value directly sidesteps that.
        accessibilityPrefs: AccessibilityPreferences(
          largeText: _base.accessibilityPrefs.largeText,
          highContrast: _base.accessibilityPrefs.highContrast,
          simplifiedInterface: _base.accessibilityPrefs.simplifiedInterface,
          textScale: _base.accessibilityPrefs.textScale,
          communicationNotes: _communicationNotesController.text.trim().isEmpty
              ? null
              : _communicationNotesController.text.trim(),
        ),
        photoUrl: _photoUrl,
      );
      final emergencyContactName =
          _emergencyContactNameController.text.trim().isEmpty
              ? null
              : _emergencyContactNameController.text.trim();
      final emergencyContactPhone =
          _emergencyContactPhoneController.text.trim().isEmpty
              ? null
              : _emergencyContactPhoneController.text.trim();
      // Same `x ?? this.x` pitfall as accessibilityPrefs above, but at the
      // entity level this time: UserProfile.copyWith can't be used to clear
      // emergencyContactName/Phone to null once set, so rebuild the entity
      // directly for those two fields instead of chaining another copyWith.
      final withEmergencyContact = UserProfile(
        userId: updated.userId,
        displayName: updated.displayName,
        photoUrl: updated.photoUrl,
        bio: updated.bio,
        locality: updated.locality,
        geoPoint: updated.geoPoint,
        skillsOffered: updated.skillsOffered,
        helpNeeded: updated.helpNeeded,
        availabilityWindows: updated.availabilityWindows,
        accessibilityPrefs: updated.accessibilityPrefs,
        emergencyContactName: emergencyContactName,
        emergencyContactPhone: emergencyContactPhone,
        languagesSpoken: updated.languagesSpoken,
        safetyPreferences: updated.safetyPreferences,
      );
      final useCase = ref.read(updateProfileUseCaseProvider);
      final result = await useCase(withEmergencyContact);
      result.fold(
        (failure) => messenger
          ..hideCurrentSnackBar()
          ..showSnackBar(SnackBar(content: Text(failure.message))),
        (_) {
          _speak('Profile saved.');
          messenger
            ..hideCurrentSnackBar()
            ..showSnackBar(
              const SnackBar(
                content: Text('✓ Profile saved.'),
                duration: Duration(seconds: 3),
              ),
            );
          if (context.canPop()) context.pop();
        },
      );
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final accessibility = ref.watch(accessibilityControllerProvider);

    return SafeArea(
      child: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(AppSpacing.lg),
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: AppLayout.maxContentWidth),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  // ── Profile photo ──────────────────────────────────────
                  Center(
                    child: Column(
                      children: [
                        Semantics(
                          label: _photoUrl == null || _photoUrl!.isEmpty
                              ? 'Profile photo: not set'
                              : 'Profile photo',
                          image: true,
                          child: _photoUrl == null || _photoUrl!.isEmpty
                              ? const AppStatusIcon(icon: Icons.person, size: 96)
                              : CircleAvatar(
                                  radius: 48,
                                  backgroundImage: NetworkImage(_photoUrl!),
                                ),
                        ),
                        const SizedBox(height: AppSpacing.sm),
                        Semantics(
                          label: 'Change profile photo button',
                          button: true,
                          child: AppButton(
                            label: 'Change photo',
                            icon: Icons.camera_alt_outlined,
                            secondary: true,
                            isLoading: _isUploadingPhoto,
                            onPressed: _changePhoto,
                          ),
                        ),
                        if (accessibility.dataSaver)
                          Padding(
                            padding: const EdgeInsets.only(top: AppSpacing.xs),
                            child: Text(
                              'Data saver: photo compressed to save data.',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context).colorScheme.onSurfaceVariant,
                                  ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // ── Display name ──────────────────────────────────────
                  AppTextField(
                    label: 'Display name',
                    controller: _nameController,
                    prefixIcon: Icons.badge_outlined,
                    textInputAction: TextInputAction.next,
                    validator: (value) =>
                        Validators.required(value, fieldName: 'Name') ??
                        Validators.maxLength(value, _nameMaxLength, fieldName: 'Name'),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ── Locality ──────────────────────────────────────────
                  AppTextField(
                    label: 'Locality',
                    hint: 'Your neighbourhood',
                    controller: _localityController,
                    prefixIcon: Icons.place_outlined,
                    textInputAction: TextInputAction.next,
                    validator: (value) =>
                        Validators.maxLength(value, _localityMaxLength, fieldName: 'Locality'),
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // ── Map location picker ───────────────────────────────
                  Semantics(
                    label: 'Location picker. Tap the map or use the current location button.',
                    child: LocationPicker(
                      initial: _geoPoint,
                      onChanged: (coords) => setState(() => _geoPoint = coords),
                    ),
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // ── Bio ───────────────────────────────────────────────
                  AppTextField(
                    label: 'About you',
                    controller: _bioController,
                    maxLines: 4,
                    validator: (value) =>
                        Validators.maxLength(value, _bioMaxLength, fieldName: 'Bio'),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ── Skills ────────────────────────────────────────────
                  AppTextField(
                    label: 'Skills you offer',
                    hint: 'e.g. gardening, cooking, tech help',
                    helperText: 'Separate with commas',
                    controller: _skillsController,
                    validator: (value) => Validators.tagList(
                      value,
                      maxCount: _tagMaxCount,
                      maxTagLength: _tagMaxLength,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ── Help needed ───────────────────────────────────────
                  AppTextField(
                    label: 'Help you need',
                    hint: 'e.g. grocery runs, company on walks',
                    helperText: 'Separate with commas',
                    controller: _helpController,
                    validator: (value) => Validators.tagList(
                      value,
                      maxCount: _tagMaxCount,
                      maxTagLength: _tagMaxLength,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ── Languages ─────────────────────────────────────────
                  AppTextField(
                    label: 'Languages you speak',
                    hint: 'e.g. English, Sinhala, Tamil',
                    helperText: 'Helps you find a volunteer who speaks your language',
                    controller: _languagesController,
                    validator: (value) => Validators.tagList(
                      value,
                      maxCount: _tagMaxCount,
                      maxTagLength: _tagMaxLength,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ── Safety preferences ────────────────────────────────
                  Semantics(
                    label: 'Safety preferences selection',
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Safety preferences',
                          style: Theme.of(context).textTheme.titleMedium,
                        ),
                        const SizedBox(height: AppSpacing.xs),
                        Wrap(
                          spacing: AppSpacing.sm,
                          runSpacing: AppSpacing.sm,
                          children: [
                            for (final option in safetyPreferenceOptions)
                              Semantics(
                                label: '$option safety preference, '
                                    '${_safetySelection.contains(option) ? "selected" : "not selected"}',
                                child: FilterChip(
                                  label: Text(option),
                                  selected: _safetySelection.contains(option),
                                  onSelected: (selected) => setState(() {
                                    if (selected) {
                                      _safetySelection.add(option);
                                    } else {
                                      _safetySelection.remove(option);
                                    }
                                  }),
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppSpacing.md),

                  // ── Communication notes ───────────────────────────────
                  AppTextField(
                    label: 'Communication notes (optional)',
                    hint: 'e.g. speaks slowly, prefers texting, hard of '
                        'hearing on the left',
                    helperText: 'Shown to a matched volunteer before a session',
                    controller: _communicationNotesController,
                    maxLines: 3,
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // ── Emergency contact ─────────────────────────────────
                  Semantics(
                    label: 'Emergency contact section',
                    child: Text(
                      'Emergency contact',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  AppTextField(
                    label: 'Contact name (optional)',
                    hint: 'e.g. a family member or close friend',
                    controller: _emergencyContactNameController,
                    prefixIcon: Icons.badge_outlined,
                    textInputAction: TextInputAction.next,
                    validator: (value) =>
                        Validators.maxLength(value, _nameMaxLength, fieldName: 'Contact name'),
                  ),
                  const SizedBox(height: AppSpacing.md),
                  AppTextField(
                    label: 'Contact phone (optional)',
                    hint: 'e.g. +94 71 234 5678',
                    helperText: 'Shown with a one-tap call button on your profile',
                    controller: _emergencyContactPhoneController,
                    prefixIcon: Icons.call_outlined,
                    keyboardType: TextInputType.phone,
                    // Validates format but allows blank (optional field).
                    validator: (value) => Validators.optionalPhone(value),
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // ── Availability ──────────────────────────────────────
                  Semantics(
                    label: 'Availability windows section',
                    child: Text(
                      'Availability',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                  ),
                  const SizedBox(height: AppSpacing.sm),
                  if (_availabilityWindows.isEmpty)
                    Text(
                      'No availability added yet.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context).colorScheme.onSurfaceVariant,
                          ),
                    )
                  else
                    AppCard(
                      child: Column(
                        children: [
                          for (var i = 0; i < _availabilityWindows.length; i++)
                            Padding(
                              padding: EdgeInsets.only(
                                bottom: i == _availabilityWindows.length - 1
                                    ? 0
                                    : AppSpacing.sm,
                              ),
                              child: Row(
                                children: [
                                  const Icon(Icons.schedule_outlined),
                                  const SizedBox(width: AppSpacing.sm),
                                  Expanded(
                                    child: Text(
                                      '${_availabilityWindows[i].dayOfWeek} '
                                      '${_availabilityWindows[i].startTime}–'
                                      '${_availabilityWindows[i].endTime}',
                                    ),
                                  ),
                                  Semantics(
                                    label: 'Remove ${_availabilityWindows[i].dayOfWeek} '
                                        '${_availabilityWindows[i].startTime}–'
                                        '${_availabilityWindows[i].endTime} availability window',
                                    button: true,
                                    child: IconButton(
                                      icon: const Icon(Icons.close),
                                      tooltip: 'Remove availability window',
                                      onPressed: () => _removeAvailabilityWindow(i),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                        ],
                      ),
                    ),
                  const SizedBox(height: AppSpacing.sm),
                  AppButton(
                    label: 'Add availability',
                    icon: Icons.add,
                    secondary: true,
                    onPressed: _addAvailabilityWindow,
                  ),
                  const SizedBox(height: AppSpacing.lg),

                  // ── Save ──────────────────────────────────────────────
                  Semantics(
                    label: 'Save profile button',
                    button: true,
                    child: AppButton(
                      label: 'Save profile',
                      isLoading: _isSaving,
                      onPressed: _save,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
