// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'trust_score_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_TrustScoreDto _$TrustScoreDtoFromJson(Map<String, dynamic> json) =>
    _TrustScoreDto(
      userId: json['userId'] as String,
      score: (json['score'] as num).toDouble(),
      completedSessions: (json['completedSessions'] as num).toInt(),
      averageRating: (json['averageRating'] as num).toDouble(),
      lastUpdatedMillis: (json['lastUpdatedMillis'] as num).toInt(),
    );

Map<String, dynamic> _$TrustScoreDtoToJson(_TrustScoreDto instance) =>
    <String, dynamic>{
      'userId': instance.userId,
      'score': instance.score,
      'completedSessions': instance.completedSessions,
      'averageRating': instance.averageRating,
      'lastUpdatedMillis': instance.lastUpdatedMillis,
    };
