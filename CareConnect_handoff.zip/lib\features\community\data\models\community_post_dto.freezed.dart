// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'community_post_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$CommunityPostDto {

 String get id; String get authorId; String get authorName; String? get authorPhotoUrl; String get text; int get createdAtMillis;
/// Create a copy of CommunityPostDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$CommunityPostDtoCopyWith<CommunityPostDto> get copyWith => _$CommunityPostDtoCopyWithImpl<CommunityPostDto>(this as CommunityPostDto, _$identity);

  /// Serializes this CommunityPostDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as CommunityPostDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is CommunityPostDto&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.authorId, _this.authorId) || other.authorId == _this.authorId)&&(identical(other.authorName, _this.authorName) || other.authorName == _this.authorName)&&(identical(other.authorPhotoUrl, _this.authorPhotoUrl) || other.authorPhotoUrl == _this.authorPhotoUrl)&&(identical(other.text, _this.text) || other.text == _this.text)&&(identical(other.createdAtMillis, _this.createdAtMillis) || other.createdAtMillis == _this.createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as CommunityPostDto;
  return Object.hash(runtimeType,_this.id,_this.authorId,_this.authorName,_this.authorPhotoUrl,_this.text,_this.createdAtMillis);
}

@override
String toString() {
  final _this = this as CommunityPostDto;
  return 'CommunityPostDto(id: ${_this.id}, authorId: ${_this.authorId}, authorName: ${_this.authorName}, authorPhotoUrl: ${_this.authorPhotoUrl}, text: ${_this.text}, createdAtMillis: ${_this.createdAtMillis})';
}


}

/// @nodoc
abstract mixin class $CommunityPostDtoCopyWith<$Res>  {
  factory $CommunityPostDtoCopyWith(CommunityPostDto value, $Res Function(CommunityPostDto) _then) = _$CommunityPostDtoCopyWithImpl;
@useResult
$Res call({
 String id, String authorId, String authorName, String? authorPhotoUrl, String text, int createdAtMillis
});




}
/// @nodoc
class _$CommunityPostDtoCopyWithImpl<$Res>
    implements $CommunityPostDtoCopyWith<$Res> {
  _$CommunityPostDtoCopyWithImpl(this._self, this._then);

  final CommunityPostDto _self;
  final $Res Function(CommunityPostDto) _then;

/// Create a copy of CommunityPostDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? authorId = null,Object? authorName = null,Object? authorPhotoUrl = freezed,Object? text = null,Object? createdAtMillis = null,}) {
  return _then(CommunityPostDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,authorId: null == authorId ? _self.authorId : authorId // ignore: cast_nullable_to_non_nullable
as String,authorName: null == authorName ? _self.authorName : authorName // ignore: cast_nullable_to_non_nullable
as String,authorPhotoUrl: freezed == authorPhotoUrl ? _self.authorPhotoUrl : authorPhotoUrl // ignore: cast_nullable_to_non_nullable
as String?,text: null == text ? _self.text : text // ignore: cast_nullable_to_non_nullable
as String,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [CommunityPostDto].
extension CommunityPostDtoPatterns on CommunityPostDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _CommunityPostDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _CommunityPostDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _CommunityPostDto value)  $default,){
final _that = this;
switch (_that) {
case _CommunityPostDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _CommunityPostDto value)?  $default,){
final _that = this;
switch (_that) {
case _CommunityPostDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String authorId,  String authorName,  String? authorPhotoUrl,  String text,  int createdAtMillis)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _CommunityPostDto() when $default != null:
return $default(_that.id,_that.authorId,_that.authorName,_that.authorPhotoUrl,_that.text,_that.createdAtMillis);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String authorId,  String authorName,  String? authorPhotoUrl,  String text,  int createdAtMillis)  $default,) {final _that = this;
switch (_that) {
case _CommunityPostDto():
return $default(_that.id,_that.authorId,_that.authorName,_that.authorPhotoUrl,_that.text,_that.createdAtMillis);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String authorId,  String authorName,  String? authorPhotoUrl,  String text,  int createdAtMillis)?  $default,) {final _that = this;
switch (_that) {
case _CommunityPostDto() when $default != null:
return $default(_that.id,_that.authorId,_that.authorName,_that.authorPhotoUrl,_that.text,_that.createdAtMillis);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _CommunityPostDto extends CommunityPostDto {
  const _CommunityPostDto({required this.id, required this.authorId, required this.authorName, this.authorPhotoUrl, required this.text, required this.createdAtMillis}): super._();
  factory _CommunityPostDto.fromJson(Map<String, dynamic> json) => _$CommunityPostDtoFromJson(json);

@override final  String id;
@override final  String authorId;
@override final  String authorName;
@override final  String? authorPhotoUrl;
@override final  String text;
@override final  int createdAtMillis;

/// Create a copy of CommunityPostDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$CommunityPostDtoCopyWith<_CommunityPostDto> get copyWith => __$CommunityPostDtoCopyWithImpl<_CommunityPostDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$CommunityPostDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _CommunityPostDto&&(identical(other.id, id) || other.id == id)&&(identical(other.authorId, authorId) || other.authorId == authorId)&&(identical(other.authorName, authorName) || other.authorName == authorName)&&(identical(other.authorPhotoUrl, authorPhotoUrl) || other.authorPhotoUrl == authorPhotoUrl)&&(identical(other.text, text) || other.text == text)&&(identical(other.createdAtMillis, createdAtMillis) || other.createdAtMillis == createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,id,authorId,authorName,authorPhotoUrl,text,createdAtMillis);
}

@override
String toString() {
    return 'CommunityPostDto(id: $id, authorId: $authorId, authorName: $authorName, authorPhotoUrl: $authorPhotoUrl, text: $text, createdAtMillis: $createdAtMillis)';
}


}

/// @nodoc
abstract mixin class _$CommunityPostDtoCopyWith<$Res> implements $CommunityPostDtoCopyWith<$Res> {
  factory _$CommunityPostDtoCopyWith(_CommunityPostDto value, $Res Function(_CommunityPostDto) _then) = __$CommunityPostDtoCopyWithImpl;
@override @useResult
$Res call({
 String id, String authorId, String authorName, String? authorPhotoUrl, String text, int createdAtMillis
});




}
/// @nodoc
class __$CommunityPostDtoCopyWithImpl<$Res>
    implements _$CommunityPostDtoCopyWith<$Res> {
  __$CommunityPostDtoCopyWithImpl(this._self, this._then);

  final _CommunityPostDto _self;
  final $Res Function(_CommunityPostDto) _then;

/// Create a copy of CommunityPostDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? authorId = null,Object? authorName = null,Object? authorPhotoUrl = freezed,Object? text = null,Object? createdAtMillis = null,}) {
  return _then(_CommunityPostDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,authorId: null == authorId ? _self.authorId : authorId // ignore: cast_nullable_to_non_nullable
as String,authorName: null == authorName ? _self.authorName : authorName // ignore: cast_nullable_to_non_nullable
as String,authorPhotoUrl: freezed == authorPhotoUrl ? _self.authorPhotoUrl : authorPhotoUrl // ignore: cast_nullable_to_non_nullable
as String?,text: null == text ? _self.text : text // ignore: cast_nullable_to_non_nullable
as String,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
