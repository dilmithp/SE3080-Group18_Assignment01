// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'user_profile_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_UserProfileDto _$UserProfileDtoFromJson(Map<String, dynamic> json) =>
    _UserProfileDto(
      userId: json['userId'] as String,
      displayName: json['displayName'] as String,
      photoUrl: json['photoUrl'] as String?,
      bio: json['bio'] as String,
      locality: json['locality'] as String,
      latitude: (json['latitude'] as num).toDouble(),
      longitude: (json['longitude'] as num).toDouble(),
      skillsOffered: (json['skillsOffered'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      helpNeeded: (json['helpNeeded'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
      availabilityWindows: (json['availabilityWindows'] as List<dynamic>)
          .map((e) => e as Map<String, dynamic>)
          .toList(),
      accessibilityPrefs: json['accessibilityPrefs'] as Map<String, dynamic>,
      emergencyContactName: json['emergencyContactName'] as String?,
      emergencyContactPhone: json['emergencyContactPhone'] as String?,
      languagesSpoken:
          (json['languagesSpoken'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const <String>[],
      safetyPreferences:
          (json['safetyPreferences'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const <String>[],
    );

Map<String, dynamic> _$UserProfileDtoToJson(_UserProfileDto instance) =>
    <String, dynamic>{
      'userId': instance.userId,
      'displayName': instance.displayName,
      'photoUrl': instance.photoUrl,
      'bio': instance.bio,
      'locality': instance.locality,
      'latitude': instance.latitude,
      'longitude': instance.longitude,
      'skillsOffered': instance.skillsOffered,
      'helpNeeded': instance.helpNeeded,
      'availabilityWindows': instance.availabilityWindows,
      'accessibilityPrefs': instance.accessibilityPrefs,
      'emergencyContactName': instance.emergencyContactName,
      'emergencyContactPhone': instance.emergencyContactPhone,
      'languagesSpoken': instance.languagesSpoken,
      'safetyPreferences': instance.safetyPreferences,
    };
