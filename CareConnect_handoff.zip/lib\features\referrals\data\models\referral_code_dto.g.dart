// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'referral_code_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_ReferralCodeDto _$ReferralCodeDtoFromJson(Map<String, dynamic> json) =>
    _ReferralCodeDto(
      code: json['code'] as String,
      ownerId: json['ownerId'] as String,
      createdAtMillis: (json['createdAtMillis'] as num).toInt(),
    );

Map<String, dynamic> _$ReferralCodeDtoToJson(_ReferralCodeDto instance) =>
    <String, dynamic>{
      'code': instance.code,
      'ownerId': instance.ownerId,
      'createdAtMillis': instance.createdAtMillis,
    };
