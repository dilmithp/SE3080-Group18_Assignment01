// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'session_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$SessionDto {

 String get id; String get requesterId; String get volunteerId; int get scheduledAtMillis; int get durationMinutes; String get status; String get location; String? get notes; bool get isRecurring; String? get recurrenceRule; int? get checkInAtMillis; int? get checkOutAtMillis; bool get conflictFlag; String? get seriesId; int? get createdAtMillis; int? get updatedAtMillis;
/// Create a copy of SessionDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$SessionDtoCopyWith<SessionDto> get copyWith => _$SessionDtoCopyWithImpl<SessionDto>(this as SessionDto, _$identity);

  /// Serializes this SessionDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as SessionDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is SessionDto&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.requesterId, _this.requesterId) || other.requesterId == _this.requesterId)&&(identical(other.volunteerId, _this.volunteerId) || other.volunteerId == _this.volunteerId)&&(identical(other.scheduledAtMillis, _this.scheduledAtMillis) || other.scheduledAtMillis == _this.scheduledAtMillis)&&(identical(other.durationMinutes, _this.durationMinutes) || other.durationMinutes == _this.durationMinutes)&&(identical(other.status, _this.status) || other.status == _this.status)&&(identical(other.location, _this.location) || other.location == _this.location)&&(identical(other.notes, _this.notes) || other.notes == _this.notes)&&(identical(other.isRecurring, _this.isRecurring) || other.isRecurring == _this.isRecurring)&&(identical(other.recurrenceRule, _this.recurrenceRule) || other.recurrenceRule == _this.recurrenceRule)&&(identical(other.checkInAtMillis, _this.checkInAtMillis) || other.checkInAtMillis == _this.checkInAtMillis)&&(identical(other.checkOutAtMillis, _this.checkOutAtMillis) || other.checkOutAtMillis == _this.checkOutAtMillis)&&(identical(other.conflictFlag, _this.conflictFlag) || other.conflictFlag == _this.conflictFlag)&&(identical(other.seriesId, _this.seriesId) || other.seriesId == _this.seriesId)&&(identical(other.createdAtMillis, _this.createdAtMillis) || other.createdAtMillis == _this.createdAtMillis)&&(identical(other.updatedAtMillis, _this.updatedAtMillis) || other.updatedAtMillis == _this.updatedAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as SessionDto;
  return Object.hash(runtimeType,_this.id,_this.requesterId,_this.volunteerId,_this.scheduledAtMillis,_this.durationMinutes,_this.status,_this.location,_this.notes,_this.isRecurring,_this.recurrenceRule,_this.checkInAtMillis,_this.checkOutAtMillis,_this.conflictFlag,_this.seriesId,_this.createdAtMillis,_this.updatedAtMillis);
}

@override
String toString() {
  final _this = this as SessionDto;
  return 'SessionDto(id: ${_this.id}, requesterId: ${_this.requesterId}, volunteerId: ${_this.volunteerId}, scheduledAtMillis: ${_this.scheduledAtMillis}, durationMinutes: ${_this.durationMinutes}, status: ${_this.status}, location: ${_this.location}, notes: ${_this.notes}, isRecurring: ${_this.isRecurring}, recurrenceRule: ${_this.recurrenceRule}, checkInAtMillis: ${_this.checkInAtMillis}, checkOutAtMillis: ${_this.checkOutAtMillis}, conflictFlag: ${_this.conflictFlag}, seriesId: ${_this.seriesId}, createdAtMillis: ${_this.createdAtMillis}, updatedAtMillis: ${_this.updatedAtMillis})';
}


}

/// @nodoc
abstract mixin class $SessionDtoCopyWith<$Res>  {
  factory $SessionDtoCopyWith(SessionDto value, $Res Function(SessionDto) _then) = _$SessionDtoCopyWithImpl;
@useResult
$Res call({
 String id, String requesterId, String volunteerId, int scheduledAtMillis, int durationMinutes, String status, String location, String? notes, bool isRecurring, String? recurrenceRule, int? checkInAtMillis, int? checkOutAtMillis, bool conflictFlag, String? seriesId, int? createdAtMillis, int? updatedAtMillis
});




}
/// @nodoc
class _$SessionDtoCopyWithImpl<$Res>
    implements $SessionDtoCopyWith<$Res> {
  _$SessionDtoCopyWithImpl(this._self, this._then);

  final SessionDto _self;
  final $Res Function(SessionDto) _then;

/// Create a copy of SessionDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? requesterId = null,Object? volunteerId = null,Object? scheduledAtMillis = null,Object? durationMinutes = null,Object? status = null,Object? location = null,Object? notes = freezed,Object? isRecurring = null,Object? recurrenceRule = freezed,Object? checkInAtMillis = freezed,Object? checkOutAtMillis = freezed,Object? conflictFlag = null,Object? seriesId = freezed,Object? createdAtMillis = freezed,Object? updatedAtMillis = freezed,}) {
  return _then(SessionDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,requesterId: null == requesterId ? _self.requesterId : requesterId // ignore: cast_nullable_to_non_nullable
as String,volunteerId: null == volunteerId ? _self.volunteerId : volunteerId // ignore: cast_nullable_to_non_nullable
as String,scheduledAtMillis: null == scheduledAtMillis ? _self.scheduledAtMillis : scheduledAtMillis // ignore: cast_nullable_to_non_nullable
as int,durationMinutes: null == durationMinutes ? _self.durationMinutes : durationMinutes // ignore: cast_nullable_to_non_nullable
as int,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as String,location: null == location ? _self.location : location // ignore: cast_nullable_to_non_nullable
as String,notes: freezed == notes ? _self.notes : notes // ignore: cast_nullable_to_non_nullable
as String?,isRecurring: null == isRecurring ? _self.isRecurring : isRecurring // ignore: cast_nullable_to_non_nullable
as bool,recurrenceRule: freezed == recurrenceRule ? _self.recurrenceRule : recurrenceRule // ignore: cast_nullable_to_non_nullable
as String?,checkInAtMillis: freezed == checkInAtMillis ? _self.checkInAtMillis : checkInAtMillis // ignore: cast_nullable_to_non_nullable
as int?,checkOutAtMillis: freezed == checkOutAtMillis ? _self.checkOutAtMillis : checkOutAtMillis // ignore: cast_nullable_to_non_nullable
as int?,conflictFlag: null == conflictFlag ? _self.conflictFlag : conflictFlag // ignore: cast_nullable_to_non_nullable
as bool,seriesId: freezed == seriesId ? _self.seriesId : seriesId // ignore: cast_nullable_to_non_nullable
as String?,createdAtMillis: freezed == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int?,updatedAtMillis: freezed == updatedAtMillis ? _self.updatedAtMillis : updatedAtMillis // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}

}


/// Adds pattern-matching-related methods to [SessionDto].
extension SessionDtoPatterns on SessionDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _SessionDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _SessionDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _SessionDto value)  $default,){
final _that = this;
switch (_that) {
case _SessionDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _SessionDto value)?  $default,){
final _that = this;
switch (_that) {
case _SessionDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String requesterId,  String volunteerId,  int scheduledAtMillis,  int durationMinutes,  String status,  String location,  String? notes,  bool isRecurring,  String? recurrenceRule,  int? checkInAtMillis,  int? checkOutAtMillis,  bool conflictFlag,  String? seriesId,  int? createdAtMillis,  int? updatedAtMillis)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _SessionDto() when $default != null:
return $default(_that.id,_that.requesterId,_that.volunteerId,_that.scheduledAtMillis,_that.durationMinutes,_that.status,_that.location,_that.notes,_that.isRecurring,_that.recurrenceRule,_that.checkInAtMillis,_that.checkOutAtMillis,_that.conflictFlag,_that.seriesId,_that.createdAtMillis,_that.updatedAtMillis);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String requesterId,  String volunteerId,  int scheduledAtMillis,  int durationMinutes,  String status,  String location,  String? notes,  bool isRecurring,  String? recurrenceRule,  int? checkInAtMillis,  int? checkOutAtMillis,  bool conflictFlag,  String? seriesId,  int? createdAtMillis,  int? updatedAtMillis)  $default,) {final _that = this;
switch (_that) {
case _SessionDto():
return $default(_that.id,_that.requesterId,_that.volunteerId,_that.scheduledAtMillis,_that.durationMinutes,_that.status,_that.location,_that.notes,_that.isRecurring,_that.recurrenceRule,_that.checkInAtMillis,_that.checkOutAtMillis,_that.conflictFlag,_that.seriesId,_that.createdAtMillis,_that.updatedAtMillis);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String requesterId,  String volunteerId,  int scheduledAtMillis,  int durationMinutes,  String status,  String location,  String? notes,  bool isRecurring,  String? recurrenceRule,  int? checkInAtMillis,  int? checkOutAtMillis,  bool conflictFlag,  String? seriesId,  int? createdAtMillis,  int? updatedAtMillis)?  $default,) {final _that = this;
switch (_that) {
case _SessionDto() when $default != null:
return $default(_that.id,_that.requesterId,_that.volunteerId,_that.scheduledAtMillis,_that.durationMinutes,_that.status,_that.location,_that.notes,_that.isRecurring,_that.recurrenceRule,_that.checkInAtMillis,_that.checkOutAtMillis,_that.conflictFlag,_that.seriesId,_that.createdAtMillis,_that.updatedAtMillis);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _SessionDto extends SessionDto {
  const _SessionDto({required this.id, required this.requesterId, required this.volunteerId, required this.scheduledAtMillis, required this.durationMinutes, required this.status, required this.location, this.notes, this.isRecurring = false, this.recurrenceRule, this.checkInAtMillis, this.checkOutAtMillis, this.conflictFlag = false, this.seriesId, this.createdAtMillis, this.updatedAtMillis}): super._();
  factory _SessionDto.fromJson(Map<String, dynamic> json) => _$SessionDtoFromJson(json);

@override final  String id;
@override final  String requesterId;
@override final  String volunteerId;
@override final  int scheduledAtMillis;
@override final  int durationMinutes;
@override final  String status;
@override final  String location;
@override final  String? notes;
@override@JsonKey() final  bool isRecurring;
@override final  String? recurrenceRule;
@override final  int? checkInAtMillis;
@override final  int? checkOutAtMillis;
@override@JsonKey() final  bool conflictFlag;
@override final  String? seriesId;
@override final  int? createdAtMillis;
@override final  int? updatedAtMillis;

/// Create a copy of SessionDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$SessionDtoCopyWith<_SessionDto> get copyWith => __$SessionDtoCopyWithImpl<_SessionDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$SessionDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _SessionDto&&(identical(other.id, id) || other.id == id)&&(identical(other.requesterId, requesterId) || other.requesterId == requesterId)&&(identical(other.volunteerId, volunteerId) || other.volunteerId == volunteerId)&&(identical(other.scheduledAtMillis, scheduledAtMillis) || other.scheduledAtMillis == scheduledAtMillis)&&(identical(other.durationMinutes, durationMinutes) || other.durationMinutes == durationMinutes)&&(identical(other.status, status) || other.status == status)&&(identical(other.location, location) || other.location == location)&&(identical(other.notes, notes) || other.notes == notes)&&(identical(other.isRecurring, isRecurring) || other.isRecurring == isRecurring)&&(identical(other.recurrenceRule, recurrenceRule) || other.recurrenceRule == recurrenceRule)&&(identical(other.checkInAtMillis, checkInAtMillis) || other.checkInAtMillis == checkInAtMillis)&&(identical(other.checkOutAtMillis, checkOutAtMillis) || other.checkOutAtMillis == checkOutAtMillis)&&(identical(other.conflictFlag, conflictFlag) || other.conflictFlag == conflictFlag)&&(identical(other.seriesId, seriesId) || other.seriesId == seriesId)&&(identical(other.createdAtMillis, createdAtMillis) || other.createdAtMillis == createdAtMillis)&&(identical(other.updatedAtMillis, updatedAtMillis) || other.updatedAtMillis == updatedAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,id,requesterId,volunteerId,scheduledAtMillis,durationMinutes,status,location,notes,isRecurring,recurrenceRule,checkInAtMillis,checkOutAtMillis,conflictFlag,seriesId,createdAtMillis,updatedAtMillis);
}

@override
String toString() {
    return 'SessionDto(id: $id, requesterId: $requesterId, volunteerId: $volunteerId, scheduledAtMillis: $scheduledAtMillis, durationMinutes: $durationMinutes, status: $status, location: $location, notes: $notes, isRecurring: $isRecurring, recurrenceRule: $recurrenceRule, checkInAtMillis: $checkInAtMillis, checkOutAtMillis: $checkOutAtMillis, conflictFlag: $conflictFlag, seriesId: $seriesId, createdAtMillis: $createdAtMillis, updatedAtMillis: $updatedAtMillis)';
}


}

/// @nodoc
abstract mixin class _$SessionDtoCopyWith<$Res> implements $SessionDtoCopyWith<$Res> {
  factory _$SessionDtoCopyWith(_SessionDto value, $Res Function(_SessionDto) _then) = __$SessionDtoCopyWithImpl;
@override @useResult
$Res call({
 String id, String requesterId, String volunteerId, int scheduledAtMillis, int durationMinutes, String status, String location, String? notes, bool isRecurring, String? recurrenceRule, int? checkInAtMillis, int? checkOutAtMillis, bool conflictFlag, String? seriesId, int? createdAtMillis, int? updatedAtMillis
});




}
/// @nodoc
class __$SessionDtoCopyWithImpl<$Res>
    implements _$SessionDtoCopyWith<$Res> {
  __$SessionDtoCopyWithImpl(this._self, this._then);

  final _SessionDto _self;
  final $Res Function(_SessionDto) _then;

/// Create a copy of SessionDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? requesterId = null,Object? volunteerId = null,Object? scheduledAtMillis = null,Object? durationMinutes = null,Object? status = null,Object? location = null,Object? notes = freezed,Object? isRecurring = null,Object? recurrenceRule = freezed,Object? checkInAtMillis = freezed,Object? checkOutAtMillis = freezed,Object? conflictFlag = null,Object? seriesId = freezed,Object? createdAtMillis = freezed,Object? updatedAtMillis = freezed,}) {
  return _then(_SessionDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,requesterId: null == requesterId ? _self.requesterId : requesterId // ignore: cast_nullable_to_non_nullable
as String,volunteerId: null == volunteerId ? _self.volunteerId : volunteerId // ignore: cast_nullable_to_non_nullable
as String,scheduledAtMillis: null == scheduledAtMillis ? _self.scheduledAtMillis : scheduledAtMillis // ignore: cast_nullable_to_non_nullable
as int,durationMinutes: null == durationMinutes ? _self.durationMinutes : durationMinutes // ignore: cast_nullable_to_non_nullable
as int,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as String,location: null == location ? _self.location : location // ignore: cast_nullable_to_non_nullable
as String,notes: freezed == notes ? _self.notes : notes // ignore: cast_nullable_to_non_nullable
as String?,isRecurring: null == isRecurring ? _self.isRecurring : isRecurring // ignore: cast_nullable_to_non_nullable
as bool,recurrenceRule: freezed == recurrenceRule ? _self.recurrenceRule : recurrenceRule // ignore: cast_nullable_to_non_nullable
as String?,checkInAtMillis: freezed == checkInAtMillis ? _self.checkInAtMillis : checkInAtMillis // ignore: cast_nullable_to_non_nullable
as int?,checkOutAtMillis: freezed == checkOutAtMillis ? _self.checkOutAtMillis : checkOutAtMillis // ignore: cast_nullable_to_non_nullable
as int?,conflictFlag: null == conflictFlag ? _self.conflictFlag : conflictFlag // ignore: cast_nullable_to_non_nullable
as bool,seriesId: freezed == seriesId ? _self.seriesId : seriesId // ignore: cast_nullable_to_non_nullable
as String?,createdAtMillis: freezed == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int?,updatedAtMillis: freezed == updatedAtMillis ? _self.updatedAtMillis : updatedAtMillis // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}


}

// dart format on
