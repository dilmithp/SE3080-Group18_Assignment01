// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'session_feedback_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_SessionFeedbackDto _$SessionFeedbackDtoFromJson(Map<String, dynamic> json) =>
    _SessionFeedbackDto(
      sessionId: json['sessionId'] as String,
      raterId: json['raterId'] as String,
      rating: (json['rating'] as num).toInt(),
      createdAtMillis: (json['createdAtMillis'] as num).toInt(),
      comment: json['comment'] as String?,
    );

Map<String, dynamic> _$SessionFeedbackDtoToJson(_SessionFeedbackDto instance) =>
    <String, dynamic>{
      'sessionId': instance.sessionId,
      'raterId': instance.raterId,
      'rating': instance.rating,
      'createdAtMillis': instance.createdAtMillis,
      'comment': instance.comment,
    };
