// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'verification_request_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$VerificationRequestDto {

 String get id; String get userId; String get documentUrl; String get status; String? get reviewedBy; int? get reviewedAtMillis;
/// Create a copy of VerificationRequestDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$VerificationRequestDtoCopyWith<VerificationRequestDto> get copyWith => _$VerificationRequestDtoCopyWithImpl<VerificationRequestDto>(this as VerificationRequestDto, _$identity);

  /// Serializes this VerificationRequestDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as VerificationRequestDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is VerificationRequestDto&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.userId, _this.userId) || other.userId == _this.userId)&&(identical(other.documentUrl, _this.documentUrl) || other.documentUrl == _this.documentUrl)&&(identical(other.status, _this.status) || other.status == _this.status)&&(identical(other.reviewedBy, _this.reviewedBy) || other.reviewedBy == _this.reviewedBy)&&(identical(other.reviewedAtMillis, _this.reviewedAtMillis) || other.reviewedAtMillis == _this.reviewedAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as VerificationRequestDto;
  return Object.hash(runtimeType,_this.id,_this.userId,_this.documentUrl,_this.status,_this.reviewedBy,_this.reviewedAtMillis);
}

@override
String toString() {
  final _this = this as VerificationRequestDto;
  return 'VerificationRequestDto(id: ${_this.id}, userId: ${_this.userId}, documentUrl: ${_this.documentUrl}, status: ${_this.status}, reviewedBy: ${_this.reviewedBy}, reviewedAtMillis: ${_this.reviewedAtMillis})';
}


}

/// @nodoc
abstract mixin class $VerificationRequestDtoCopyWith<$Res>  {
  factory $VerificationRequestDtoCopyWith(VerificationRequestDto value, $Res Function(VerificationRequestDto) _then) = _$VerificationRequestDtoCopyWithImpl;
@useResult
$Res call({
 String id, String userId, String documentUrl, String status, String? reviewedBy, int? reviewedAtMillis
});




}
/// @nodoc
class _$VerificationRequestDtoCopyWithImpl<$Res>
    implements $VerificationRequestDtoCopyWith<$Res> {
  _$VerificationRequestDtoCopyWithImpl(this._self, this._then);

  final VerificationRequestDto _self;
  final $Res Function(VerificationRequestDto) _then;

/// Create a copy of VerificationRequestDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? userId = null,Object? documentUrl = null,Object? status = null,Object? reviewedBy = freezed,Object? reviewedAtMillis = freezed,}) {
  return _then(VerificationRequestDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,documentUrl: null == documentUrl ? _self.documentUrl : documentUrl // ignore: cast_nullable_to_non_nullable
as String,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as String,reviewedBy: freezed == reviewedBy ? _self.reviewedBy : reviewedBy // ignore: cast_nullable_to_non_nullable
as String?,reviewedAtMillis: freezed == reviewedAtMillis ? _self.reviewedAtMillis : reviewedAtMillis // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}

}


/// Adds pattern-matching-related methods to [VerificationRequestDto].
extension VerificationRequestDtoPatterns on VerificationRequestDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _VerificationRequestDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _VerificationRequestDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _VerificationRequestDto value)  $default,){
final _that = this;
switch (_that) {
case _VerificationRequestDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _VerificationRequestDto value)?  $default,){
final _that = this;
switch (_that) {
case _VerificationRequestDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String userId,  String documentUrl,  String status,  String? reviewedBy,  int? reviewedAtMillis)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _VerificationRequestDto() when $default != null:
return $default(_that.id,_that.userId,_that.documentUrl,_that.status,_that.reviewedBy,_that.reviewedAtMillis);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String userId,  String documentUrl,  String status,  String? reviewedBy,  int? reviewedAtMillis)  $default,) {final _that = this;
switch (_that) {
case _VerificationRequestDto():
return $default(_that.id,_that.userId,_that.documentUrl,_that.status,_that.reviewedBy,_that.reviewedAtMillis);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String userId,  String documentUrl,  String status,  String? reviewedBy,  int? reviewedAtMillis)?  $default,) {final _that = this;
switch (_that) {
case _VerificationRequestDto() when $default != null:
return $default(_that.id,_that.userId,_that.documentUrl,_that.status,_that.reviewedBy,_that.reviewedAtMillis);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _VerificationRequestDto extends VerificationRequestDto {
  const _VerificationRequestDto({required this.id, required this.userId, required this.documentUrl, required this.status, this.reviewedBy, this.reviewedAtMillis}): super._();
  factory _VerificationRequestDto.fromJson(Map<String, dynamic> json) => _$VerificationRequestDtoFromJson(json);

@override final  String id;
@override final  String userId;
@override final  String documentUrl;
@override final  String status;
@override final  String? reviewedBy;
@override final  int? reviewedAtMillis;

/// Create a copy of VerificationRequestDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$VerificationRequestDtoCopyWith<_VerificationRequestDto> get copyWith => __$VerificationRequestDtoCopyWithImpl<_VerificationRequestDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$VerificationRequestDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _VerificationRequestDto&&(identical(other.id, id) || other.id == id)&&(identical(other.userId, userId) || other.userId == userId)&&(identical(other.documentUrl, documentUrl) || other.documentUrl == documentUrl)&&(identical(other.status, status) || other.status == status)&&(identical(other.reviewedBy, reviewedBy) || other.reviewedBy == reviewedBy)&&(identical(other.reviewedAtMillis, reviewedAtMillis) || other.reviewedAtMillis == reviewedAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,id,userId,documentUrl,status,reviewedBy,reviewedAtMillis);
}

@override
String toString() {
    return 'VerificationRequestDto(id: $id, userId: $userId, documentUrl: $documentUrl, status: $status, reviewedBy: $reviewedBy, reviewedAtMillis: $reviewedAtMillis)';
}


}

/// @nodoc
abstract mixin class _$VerificationRequestDtoCopyWith<$Res> implements $VerificationRequestDtoCopyWith<$Res> {
  factory _$VerificationRequestDtoCopyWith(_VerificationRequestDto value, $Res Function(_VerificationRequestDto) _then) = __$VerificationRequestDtoCopyWithImpl;
@override @useResult
$Res call({
 String id, String userId, String documentUrl, String status, String? reviewedBy, int? reviewedAtMillis
});




}
/// @nodoc
class __$VerificationRequestDtoCopyWithImpl<$Res>
    implements _$VerificationRequestDtoCopyWith<$Res> {
  __$VerificationRequestDtoCopyWithImpl(this._self, this._then);

  final _VerificationRequestDto _self;
  final $Res Function(_VerificationRequestDto) _then;

/// Create a copy of VerificationRequestDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? userId = null,Object? documentUrl = null,Object? status = null,Object? reviewedBy = freezed,Object? reviewedAtMillis = freezed,}) {
  return _then(_VerificationRequestDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,documentUrl: null == documentUrl ? _self.documentUrl : documentUrl // ignore: cast_nullable_to_non_nullable
as String,status: null == status ? _self.status : status // ignore: cast_nullable_to_non_nullable
as String,reviewedBy: freezed == reviewedBy ? _self.reviewedBy : reviewedBy // ignore: cast_nullable_to_non_nullable
as String?,reviewedAtMillis: freezed == reviewedAtMillis ? _self.reviewedAtMillis : reviewedAtMillis // ignore: cast_nullable_to_non_nullable
as int?,
  ));
}


}

// dart format on
