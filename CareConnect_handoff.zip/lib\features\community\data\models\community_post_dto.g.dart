// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'community_post_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_CommunityPostDto _$CommunityPostDtoFromJson(Map<String, dynamic> json) =>
    _CommunityPostDto(
      id: json['id'] as String,
      authorId: json['authorId'] as String,
      authorName: json['authorName'] as String,
      authorPhotoUrl: json['authorPhotoUrl'] as String?,
      text: json['text'] as String,
      createdAtMillis: (json['createdAtMillis'] as num).toInt(),
    );

Map<String, dynamic> _$CommunityPostDtoToJson(_CommunityPostDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'authorId': instance.authorId,
      'authorName': instance.authorName,
      'authorPhotoUrl': instance.authorPhotoUrl,
      'text': instance.text,
      'createdAtMillis': instance.createdAtMillis,
    };
