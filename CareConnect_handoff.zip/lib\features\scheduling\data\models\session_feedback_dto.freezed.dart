// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'session_feedback_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$SessionFeedbackDto {

 String get sessionId; String get raterId; int get rating; int get createdAtMillis; String? get comment;
/// Create a copy of SessionFeedbackDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$SessionFeedbackDtoCopyWith<SessionFeedbackDto> get copyWith => _$SessionFeedbackDtoCopyWithImpl<SessionFeedbackDto>(this as SessionFeedbackDto, _$identity);

  /// Serializes this SessionFeedbackDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as SessionFeedbackDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is SessionFeedbackDto&&(identical(other.sessionId, _this.sessionId) || other.sessionId == _this.sessionId)&&(identical(other.raterId, _this.raterId) || other.raterId == _this.raterId)&&(identical(other.rating, _this.rating) || other.rating == _this.rating)&&(identical(other.createdAtMillis, _this.createdAtMillis) || other.createdAtMillis == _this.createdAtMillis)&&(identical(other.comment, _this.comment) || other.comment == _this.comment));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as SessionFeedbackDto;
  return Object.hash(runtimeType,_this.sessionId,_this.raterId,_this.rating,_this.createdAtMillis,_this.comment);
}

@override
String toString() {
  final _this = this as SessionFeedbackDto;
  return 'SessionFeedbackDto(sessionId: ${_this.sessionId}, raterId: ${_this.raterId}, rating: ${_this.rating}, createdAtMillis: ${_this.createdAtMillis}, comment: ${_this.comment})';
}


}

/// @nodoc
abstract mixin class $SessionFeedbackDtoCopyWith<$Res>  {
  factory $SessionFeedbackDtoCopyWith(SessionFeedbackDto value, $Res Function(SessionFeedbackDto) _then) = _$SessionFeedbackDtoCopyWithImpl;
@useResult
$Res call({
 String sessionId, String raterId, int rating, int createdAtMillis, String? comment
});




}
/// @nodoc
class _$SessionFeedbackDtoCopyWithImpl<$Res>
    implements $SessionFeedbackDtoCopyWith<$Res> {
  _$SessionFeedbackDtoCopyWithImpl(this._self, this._then);

  final SessionFeedbackDto _self;
  final $Res Function(SessionFeedbackDto) _then;

/// Create a copy of SessionFeedbackDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? sessionId = null,Object? raterId = null,Object? rating = null,Object? createdAtMillis = null,Object? comment = freezed,}) {
  return _then(SessionFeedbackDto(
sessionId: null == sessionId ? _self.sessionId : sessionId // ignore: cast_nullable_to_non_nullable
as String,raterId: null == raterId ? _self.raterId : raterId // ignore: cast_nullable_to_non_nullable
as String,rating: null == rating ? _self.rating : rating // ignore: cast_nullable_to_non_nullable
as int,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,comment: freezed == comment ? _self.comment : comment // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}

}


/// Adds pattern-matching-related methods to [SessionFeedbackDto].
extension SessionFeedbackDtoPatterns on SessionFeedbackDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _SessionFeedbackDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _SessionFeedbackDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _SessionFeedbackDto value)  $default,){
final _that = this;
switch (_that) {
case _SessionFeedbackDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _SessionFeedbackDto value)?  $default,){
final _that = this;
switch (_that) {
case _SessionFeedbackDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String sessionId,  String raterId,  int rating,  int createdAtMillis,  String? comment)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _SessionFeedbackDto() when $default != null:
return $default(_that.sessionId,_that.raterId,_that.rating,_that.createdAtMillis,_that.comment);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String sessionId,  String raterId,  int rating,  int createdAtMillis,  String? comment)  $default,) {final _that = this;
switch (_that) {
case _SessionFeedbackDto():
return $default(_that.sessionId,_that.raterId,_that.rating,_that.createdAtMillis,_that.comment);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String sessionId,  String raterId,  int rating,  int createdAtMillis,  String? comment)?  $default,) {final _that = this;
switch (_that) {
case _SessionFeedbackDto() when $default != null:
return $default(_that.sessionId,_that.raterId,_that.rating,_that.createdAtMillis,_that.comment);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _SessionFeedbackDto extends SessionFeedbackDto {
  const _SessionFeedbackDto({required this.sessionId, required this.raterId, required this.rating, required this.createdAtMillis, this.comment}): super._();
  factory _SessionFeedbackDto.fromJson(Map<String, dynamic> json) => _$SessionFeedbackDtoFromJson(json);

@override final  String sessionId;
@override final  String raterId;
@override final  int rating;
@override final  int createdAtMillis;
@override final  String? comment;

/// Create a copy of SessionFeedbackDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$SessionFeedbackDtoCopyWith<_SessionFeedbackDto> get copyWith => __$SessionFeedbackDtoCopyWithImpl<_SessionFeedbackDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$SessionFeedbackDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _SessionFeedbackDto&&(identical(other.sessionId, sessionId) || other.sessionId == sessionId)&&(identical(other.raterId, raterId) || other.raterId == raterId)&&(identical(other.rating, rating) || other.rating == rating)&&(identical(other.createdAtMillis, createdAtMillis) || other.createdAtMillis == createdAtMillis)&&(identical(other.comment, comment) || other.comment == comment));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,sessionId,raterId,rating,createdAtMillis,comment);
}

@override
String toString() {
    return 'SessionFeedbackDto(sessionId: $sessionId, raterId: $raterId, rating: $rating, createdAtMillis: $createdAtMillis, comment: $comment)';
}


}

/// @nodoc
abstract mixin class _$SessionFeedbackDtoCopyWith<$Res> implements $SessionFeedbackDtoCopyWith<$Res> {
  factory _$SessionFeedbackDtoCopyWith(_SessionFeedbackDto value, $Res Function(_SessionFeedbackDto) _then) = __$SessionFeedbackDtoCopyWithImpl;
@override @useResult
$Res call({
 String sessionId, String raterId, int rating, int createdAtMillis, String? comment
});




}
/// @nodoc
class __$SessionFeedbackDtoCopyWithImpl<$Res>
    implements _$SessionFeedbackDtoCopyWith<$Res> {
  __$SessionFeedbackDtoCopyWithImpl(this._self, this._then);

  final _SessionFeedbackDto _self;
  final $Res Function(_SessionFeedbackDto) _then;

/// Create a copy of SessionFeedbackDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? sessionId = null,Object? raterId = null,Object? rating = null,Object? createdAtMillis = null,Object? comment = freezed,}) {
  return _then(_SessionFeedbackDto(
sessionId: null == sessionId ? _self.sessionId : sessionId // ignore: cast_nullable_to_non_nullable
as String,raterId: null == raterId ? _self.raterId : raterId // ignore: cast_nullable_to_non_nullable
as String,rating: null == rating ? _self.rating : rating // ignore: cast_nullable_to_non_nullable
as int,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,comment: freezed == comment ? _self.comment : comment // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}


}

// dart format on
