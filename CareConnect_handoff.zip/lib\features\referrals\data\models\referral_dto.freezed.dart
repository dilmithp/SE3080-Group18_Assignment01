// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'referral_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$ReferralDto {

 String get id; String get code; String get referrerId; String get referredUserId; String get referredName; int get createdAtMillis;
/// Create a copy of ReferralDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ReferralDtoCopyWith<ReferralDto> get copyWith => _$ReferralDtoCopyWithImpl<ReferralDto>(this as ReferralDto, _$identity);

  /// Serializes this ReferralDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as ReferralDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ReferralDto&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.code, _this.code) || other.code == _this.code)&&(identical(other.referrerId, _this.referrerId) || other.referrerId == _this.referrerId)&&(identical(other.referredUserId, _this.referredUserId) || other.referredUserId == _this.referredUserId)&&(identical(other.referredName, _this.referredName) || other.referredName == _this.referredName)&&(identical(other.createdAtMillis, _this.createdAtMillis) || other.createdAtMillis == _this.createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as ReferralDto;
  return Object.hash(runtimeType,_this.id,_this.code,_this.referrerId,_this.referredUserId,_this.referredName,_this.createdAtMillis);
}

@override
String toString() {
  final _this = this as ReferralDto;
  return 'ReferralDto(id: ${_this.id}, code: ${_this.code}, referrerId: ${_this.referrerId}, referredUserId: ${_this.referredUserId}, referredName: ${_this.referredName}, createdAtMillis: ${_this.createdAtMillis})';
}


}

/// @nodoc
abstract mixin class $ReferralDtoCopyWith<$Res>  {
  factory $ReferralDtoCopyWith(ReferralDto value, $Res Function(ReferralDto) _then) = _$ReferralDtoCopyWithImpl;
@useResult
$Res call({
 String id, String code, String referrerId, String referredUserId, String referredName, int createdAtMillis
});




}
/// @nodoc
class _$ReferralDtoCopyWithImpl<$Res>
    implements $ReferralDtoCopyWith<$Res> {
  _$ReferralDtoCopyWithImpl(this._self, this._then);

  final ReferralDto _self;
  final $Res Function(ReferralDto) _then;

/// Create a copy of ReferralDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? code = null,Object? referrerId = null,Object? referredUserId = null,Object? referredName = null,Object? createdAtMillis = null,}) {
  return _then(ReferralDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,code: null == code ? _self.code : code // ignore: cast_nullable_to_non_nullable
as String,referrerId: null == referrerId ? _self.referrerId : referrerId // ignore: cast_nullable_to_non_nullable
as String,referredUserId: null == referredUserId ? _self.referredUserId : referredUserId // ignore: cast_nullable_to_non_nullable
as String,referredName: null == referredName ? _self.referredName : referredName // ignore: cast_nullable_to_non_nullable
as String,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [ReferralDto].
extension ReferralDtoPatterns on ReferralDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _ReferralDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _ReferralDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _ReferralDto value)  $default,){
final _that = this;
switch (_that) {
case _ReferralDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _ReferralDto value)?  $default,){
final _that = this;
switch (_that) {
case _ReferralDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String code,  String referrerId,  String referredUserId,  String referredName,  int createdAtMillis)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _ReferralDto() when $default != null:
return $default(_that.id,_that.code,_that.referrerId,_that.referredUserId,_that.referredName,_that.createdAtMillis);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String code,  String referrerId,  String referredUserId,  String referredName,  int createdAtMillis)  $default,) {final _that = this;
switch (_that) {
case _ReferralDto():
return $default(_that.id,_that.code,_that.referrerId,_that.referredUserId,_that.referredName,_that.createdAtMillis);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String code,  String referrerId,  String referredUserId,  String referredName,  int createdAtMillis)?  $default,) {final _that = this;
switch (_that) {
case _ReferralDto() when $default != null:
return $default(_that.id,_that.code,_that.referrerId,_that.referredUserId,_that.referredName,_that.createdAtMillis);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _ReferralDto extends ReferralDto {
  const _ReferralDto({required this.id, required this.code, required this.referrerId, required this.referredUserId, required this.referredName, required this.createdAtMillis}): super._();
  factory _ReferralDto.fromJson(Map<String, dynamic> json) => _$ReferralDtoFromJson(json);

@override final  String id;
@override final  String code;
@override final  String referrerId;
@override final  String referredUserId;
@override final  String referredName;
@override final  int createdAtMillis;

/// Create a copy of ReferralDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$ReferralDtoCopyWith<_ReferralDto> get copyWith => __$ReferralDtoCopyWithImpl<_ReferralDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$ReferralDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _ReferralDto&&(identical(other.id, id) || other.id == id)&&(identical(other.code, code) || other.code == code)&&(identical(other.referrerId, referrerId) || other.referrerId == referrerId)&&(identical(other.referredUserId, referredUserId) || other.referredUserId == referredUserId)&&(identical(other.referredName, referredName) || other.referredName == referredName)&&(identical(other.createdAtMillis, createdAtMillis) || other.createdAtMillis == createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,id,code,referrerId,referredUserId,referredName,createdAtMillis);
}

@override
String toString() {
    return 'ReferralDto(id: $id, code: $code, referrerId: $referrerId, referredUserId: $referredUserId, referredName: $referredName, createdAtMillis: $createdAtMillis)';
}


}

/// @nodoc
abstract mixin class _$ReferralDtoCopyWith<$Res> implements $ReferralDtoCopyWith<$Res> {
  factory _$ReferralDtoCopyWith(_ReferralDto value, $Res Function(_ReferralDto) _then) = __$ReferralDtoCopyWithImpl;
@override @useResult
$Res call({
 String id, String code, String referrerId, String referredUserId, String referredName, int createdAtMillis
});




}
/// @nodoc
class __$ReferralDtoCopyWithImpl<$Res>
    implements _$ReferralDtoCopyWith<$Res> {
  __$ReferralDtoCopyWithImpl(this._self, this._then);

  final _ReferralDto _self;
  final $Res Function(_ReferralDto) _then;

/// Create a copy of ReferralDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? code = null,Object? referrerId = null,Object? referredUserId = null,Object? referredName = null,Object? createdAtMillis = null,}) {
  return _then(_ReferralDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,code: null == code ? _self.code : code // ignore: cast_nullable_to_non_nullable
as String,referrerId: null == referrerId ? _self.referrerId : referrerId // ignore: cast_nullable_to_non_nullable
as String,referredUserId: null == referredUserId ? _self.referredUserId : referredUserId // ignore: cast_nullable_to_non_nullable
as String,referredName: null == referredName ? _self.referredName : referredName // ignore: cast_nullable_to_non_nullable
as String,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
