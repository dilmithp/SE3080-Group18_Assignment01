// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'match_candidate_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_MatchCandidateDto _$MatchCandidateDtoFromJson(Map<String, dynamic> json) =>
    _MatchCandidateDto(
      userId: json['userId'] as String,
      profile: json['profile'] as Map<String, dynamic>,
      distanceKm: (json['distanceKm'] as num).toDouble(),
      trustScore: (json['trustScore'] as num).toDouble(),
      matchScore: (json['matchScore'] as num).toDouble(),
      matchReasons: (json['matchReasons'] as List<dynamic>)
          .map((e) => e as String)
          .toList(),
    );

Map<String, dynamic> _$MatchCandidateDtoToJson(_MatchCandidateDto instance) =>
    <String, dynamic>{
      'userId': instance.userId,
      'profile': instance.profile,
      'distanceKm': instance.distanceKm,
      'trustScore': instance.trustScore,
      'matchScore': instance.matchScore,
      'matchReasons': instance.matchReasons,
    };
