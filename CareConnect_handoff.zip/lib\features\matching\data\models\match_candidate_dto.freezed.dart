// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'match_candidate_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$MatchCandidateDto {

 String get userId; Map<String, dynamic> get profile; double get distanceKm; double get trustScore; double get matchScore; List<String> get matchReasons;
/// Create a copy of MatchCandidateDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$MatchCandidateDtoCopyWith<MatchCandidateDto> get copyWith => _$MatchCandidateDtoCopyWithImpl<MatchCandidateDto>(this as MatchCandidateDto, _$identity);

  /// Serializes this MatchCandidateDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as MatchCandidateDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is MatchCandidateDto&&(identical(other.userId, _this.userId) || other.userId == _this.userId)&&const DeepCollectionEquality().equals(other.profile, _this.profile)&&(identical(other.distanceKm, _this.distanceKm) || other.distanceKm == _this.distanceKm)&&(identical(other.trustScore, _this.trustScore) || other.trustScore == _this.trustScore)&&(identical(other.matchScore, _this.matchScore) || other.matchScore == _this.matchScore)&&const DeepCollectionEquality().equals(other.matchReasons, _this.matchReasons));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as MatchCandidateDto;
  return Object.hash(runtimeType,_this.userId,const DeepCollectionEquality().hash(_this.profile),_this.distanceKm,_this.trustScore,_this.matchScore,const DeepCollectionEquality().hash(_this.matchReasons));
}

@override
String toString() {
  final _this = this as MatchCandidateDto;
  return 'MatchCandidateDto(userId: ${_this.userId}, profile: ${_this.profile}, distanceKm: ${_this.distanceKm}, trustScore: ${_this.trustScore}, matchScore: ${_this.matchScore}, matchReasons: ${_this.matchReasons})';
}


}

/// @nodoc
abstract mixin class $MatchCandidateDtoCopyWith<$Res>  {
  factory $MatchCandidateDtoCopyWith(MatchCandidateDto value, $Res Function(MatchCandidateDto) _then) = _$MatchCandidateDtoCopyWithImpl;
@useResult
$Res call({
 String userId, Map<String, dynamic> profile, double distanceKm, double trustScore, double matchScore, List<String> matchReasons
});




}
/// @nodoc
class _$MatchCandidateDtoCopyWithImpl<$Res>
    implements $MatchCandidateDtoCopyWith<$Res> {
  _$MatchCandidateDtoCopyWithImpl(this._self, this._then);

  final MatchCandidateDto _self;
  final $Res Function(MatchCandidateDto) _then;

/// Create a copy of MatchCandidateDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? userId = null,Object? profile = null,Object? distanceKm = null,Object? trustScore = null,Object? matchScore = null,Object? matchReasons = null,}) {
  return _then(MatchCandidateDto(
userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,profile: null == profile ? _self.profile : profile // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>,distanceKm: null == distanceKm ? _self.distanceKm : distanceKm // ignore: cast_nullable_to_non_nullable
as double,trustScore: null == trustScore ? _self.trustScore : trustScore // ignore: cast_nullable_to_non_nullable
as double,matchScore: null == matchScore ? _self.matchScore : matchScore // ignore: cast_nullable_to_non_nullable
as double,matchReasons: null == matchReasons ? _self.matchReasons : matchReasons // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}

}


/// Adds pattern-matching-related methods to [MatchCandidateDto].
extension MatchCandidateDtoPatterns on MatchCandidateDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _MatchCandidateDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _MatchCandidateDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _MatchCandidateDto value)  $default,){
final _that = this;
switch (_that) {
case _MatchCandidateDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _MatchCandidateDto value)?  $default,){
final _that = this;
switch (_that) {
case _MatchCandidateDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String userId,  Map<String, dynamic> profile,  double distanceKm,  double trustScore,  double matchScore,  List<String> matchReasons)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _MatchCandidateDto() when $default != null:
return $default(_that.userId,_that.profile,_that.distanceKm,_that.trustScore,_that.matchScore,_that.matchReasons);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String userId,  Map<String, dynamic> profile,  double distanceKm,  double trustScore,  double matchScore,  List<String> matchReasons)  $default,) {final _that = this;
switch (_that) {
case _MatchCandidateDto():
return $default(_that.userId,_that.profile,_that.distanceKm,_that.trustScore,_that.matchScore,_that.matchReasons);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String userId,  Map<String, dynamic> profile,  double distanceKm,  double trustScore,  double matchScore,  List<String> matchReasons)?  $default,) {final _that = this;
switch (_that) {
case _MatchCandidateDto() when $default != null:
return $default(_that.userId,_that.profile,_that.distanceKm,_that.trustScore,_that.matchScore,_that.matchReasons);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _MatchCandidateDto extends MatchCandidateDto {
  const _MatchCandidateDto({required this.userId, required  Map<String, dynamic> profile, required this.distanceKm, required this.trustScore, required this.matchScore, required  List<String> matchReasons}): _profile = profile,_matchReasons = matchReasons,super._();
  factory _MatchCandidateDto.fromJson(Map<String, dynamic> json) => _$MatchCandidateDtoFromJson(json);

@override final  String userId;
 final  Map<String, dynamic> _profile;
@override Map<String, dynamic> get profile {
  if (_profile is EqualUnmodifiableMapView) return _profile;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableMapView(_profile);
}

@override final  double distanceKm;
@override final  double trustScore;
@override final  double matchScore;
 final  List<String> _matchReasons;
@override List<String> get matchReasons {
  if (_matchReasons is EqualUnmodifiableListView) return _matchReasons;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_matchReasons);
}


/// Create a copy of MatchCandidateDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$MatchCandidateDtoCopyWith<_MatchCandidateDto> get copyWith => __$MatchCandidateDtoCopyWithImpl<_MatchCandidateDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$MatchCandidateDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _MatchCandidateDto&&(identical(other.userId, userId) || other.userId == userId)&&const DeepCollectionEquality().equals(other.profile, _profile)&&(identical(other.distanceKm, distanceKm) || other.distanceKm == distanceKm)&&(identical(other.trustScore, trustScore) || other.trustScore == trustScore)&&(identical(other.matchScore, matchScore) || other.matchScore == matchScore)&&const DeepCollectionEquality().equals(other.matchReasons, _matchReasons));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,userId,const DeepCollectionEquality().hash(_profile),distanceKm,trustScore,matchScore,const DeepCollectionEquality().hash(_matchReasons));
}

@override
String toString() {
    return 'MatchCandidateDto(userId: $userId, profile: $profile, distanceKm: $distanceKm, trustScore: $trustScore, matchScore: $matchScore, matchReasons: $matchReasons)';
}


}

/// @nodoc
abstract mixin class _$MatchCandidateDtoCopyWith<$Res> implements $MatchCandidateDtoCopyWith<$Res> {
  factory _$MatchCandidateDtoCopyWith(_MatchCandidateDto value, $Res Function(_MatchCandidateDto) _then) = __$MatchCandidateDtoCopyWithImpl;
@override @useResult
$Res call({
 String userId, Map<String, dynamic> profile, double distanceKm, double trustScore, double matchScore, List<String> matchReasons
});




}
/// @nodoc
class __$MatchCandidateDtoCopyWithImpl<$Res>
    implements _$MatchCandidateDtoCopyWith<$Res> {
  __$MatchCandidateDtoCopyWithImpl(this._self, this._then);

  final _MatchCandidateDto _self;
  final $Res Function(_MatchCandidateDto) _then;

/// Create a copy of MatchCandidateDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? userId = null,Object? profile = null,Object? distanceKm = null,Object? trustScore = null,Object? matchScore = null,Object? matchReasons = null,}) {
  return _then(_MatchCandidateDto(
userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,profile: null == profile ? _self._profile : profile // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>,distanceKm: null == distanceKm ? _self.distanceKm : distanceKm // ignore: cast_nullable_to_non_nullable
as double,trustScore: null == trustScore ? _self.trustScore : trustScore // ignore: cast_nullable_to_non_nullable
as double,matchScore: null == matchScore ? _self.matchScore : matchScore // ignore: cast_nullable_to_non_nullable
as double,matchReasons: null == matchReasons ? _self._matchReasons : matchReasons // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}


}

// dart format on
