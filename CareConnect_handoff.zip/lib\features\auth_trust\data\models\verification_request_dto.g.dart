// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'verification_request_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_VerificationRequestDto _$VerificationRequestDtoFromJson(
  Map<String, dynamic> json,
) => _VerificationRequestDto(
  id: json['id'] as String,
  userId: json['userId'] as String,
  documentUrl: json['documentUrl'] as String,
  status: json['status'] as String,
  reviewedBy: json['reviewedBy'] as String?,
  reviewedAtMillis: (json['reviewedAtMillis'] as num?)?.toInt(),
);

Map<String, dynamic> _$VerificationRequestDtoToJson(
  _VerificationRequestDto instance,
) => <String, dynamic>{
  'id': instance.id,
  'userId': instance.userId,
  'documentUrl': instance.documentUrl,
  'status': instance.status,
  'reviewedBy': instance.reviewedBy,
  'reviewedAtMillis': instance.reviewedAtMillis,
};
