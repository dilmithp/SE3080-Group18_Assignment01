// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'app_user_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$AppUserDto {

 String get id; String get email; String get phone; String get role; bool get isVerified; int get createdAtMillis;
/// Create a copy of AppUserDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$AppUserDtoCopyWith<AppUserDto> get copyWith => _$AppUserDtoCopyWithImpl<AppUserDto>(this as AppUserDto, _$identity);

  /// Serializes this AppUserDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as AppUserDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is AppUserDto&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.email, _this.email) || other.email == _this.email)&&(identical(other.phone, _this.phone) || other.phone == _this.phone)&&(identical(other.role, _this.role) || other.role == _this.role)&&(identical(other.isVerified, _this.isVerified) || other.isVerified == _this.isVerified)&&(identical(other.createdAtMillis, _this.createdAtMillis) || other.createdAtMillis == _this.createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as AppUserDto;
  return Object.hash(runtimeType,_this.id,_this.email,_this.phone,_this.role,_this.isVerified,_this.createdAtMillis);
}

@override
String toString() {
  final _this = this as AppUserDto;
  return 'AppUserDto(id: ${_this.id}, email: ${_this.email}, phone: ${_this.phone}, role: ${_this.role}, isVerified: ${_this.isVerified}, createdAtMillis: ${_this.createdAtMillis})';
}


}

/// @nodoc
abstract mixin class $AppUserDtoCopyWith<$Res>  {
  factory $AppUserDtoCopyWith(AppUserDto value, $Res Function(AppUserDto) _then) = _$AppUserDtoCopyWithImpl;
@useResult
$Res call({
 String id, String email, String phone, String role, bool isVerified, int createdAtMillis
});




}
/// @nodoc
class _$AppUserDtoCopyWithImpl<$Res>
    implements $AppUserDtoCopyWith<$Res> {
  _$AppUserDtoCopyWithImpl(this._self, this._then);

  final AppUserDto _self;
  final $Res Function(AppUserDto) _then;

/// Create a copy of AppUserDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? email = null,Object? phone = null,Object? role = null,Object? isVerified = null,Object? createdAtMillis = null,}) {
  return _then(AppUserDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,phone: null == phone ? _self.phone : phone // ignore: cast_nullable_to_non_nullable
as String,role: null == role ? _self.role : role // ignore: cast_nullable_to_non_nullable
as String,isVerified: null == isVerified ? _self.isVerified : isVerified // ignore: cast_nullable_to_non_nullable
as bool,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [AppUserDto].
extension AppUserDtoPatterns on AppUserDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _AppUserDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _AppUserDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _AppUserDto value)  $default,){
final _that = this;
switch (_that) {
case _AppUserDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _AppUserDto value)?  $default,){
final _that = this;
switch (_that) {
case _AppUserDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String email,  String phone,  String role,  bool isVerified,  int createdAtMillis)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _AppUserDto() when $default != null:
return $default(_that.id,_that.email,_that.phone,_that.role,_that.isVerified,_that.createdAtMillis);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String email,  String phone,  String role,  bool isVerified,  int createdAtMillis)  $default,) {final _that = this;
switch (_that) {
case _AppUserDto():
return $default(_that.id,_that.email,_that.phone,_that.role,_that.isVerified,_that.createdAtMillis);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String email,  String phone,  String role,  bool isVerified,  int createdAtMillis)?  $default,) {final _that = this;
switch (_that) {
case _AppUserDto() when $default != null:
return $default(_that.id,_that.email,_that.phone,_that.role,_that.isVerified,_that.createdAtMillis);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _AppUserDto extends AppUserDto {
  const _AppUserDto({required this.id, required this.email, required this.phone, required this.role, required this.isVerified, required this.createdAtMillis}): super._();
  factory _AppUserDto.fromJson(Map<String, dynamic> json) => _$AppUserDtoFromJson(json);

@override final  String id;
@override final  String email;
@override final  String phone;
@override final  String role;
@override final  bool isVerified;
@override final  int createdAtMillis;

/// Create a copy of AppUserDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$AppUserDtoCopyWith<_AppUserDto> get copyWith => __$AppUserDtoCopyWithImpl<_AppUserDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$AppUserDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _AppUserDto&&(identical(other.id, id) || other.id == id)&&(identical(other.email, email) || other.email == email)&&(identical(other.phone, phone) || other.phone == phone)&&(identical(other.role, role) || other.role == role)&&(identical(other.isVerified, isVerified) || other.isVerified == isVerified)&&(identical(other.createdAtMillis, createdAtMillis) || other.createdAtMillis == createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,id,email,phone,role,isVerified,createdAtMillis);
}

@override
String toString() {
    return 'AppUserDto(id: $id, email: $email, phone: $phone, role: $role, isVerified: $isVerified, createdAtMillis: $createdAtMillis)';
}


}

/// @nodoc
abstract mixin class _$AppUserDtoCopyWith<$Res> implements $AppUserDtoCopyWith<$Res> {
  factory _$AppUserDtoCopyWith(_AppUserDto value, $Res Function(_AppUserDto) _then) = __$AppUserDtoCopyWithImpl;
@override @useResult
$Res call({
 String id, String email, String phone, String role, bool isVerified, int createdAtMillis
});




}
/// @nodoc
class __$AppUserDtoCopyWithImpl<$Res>
    implements _$AppUserDtoCopyWith<$Res> {
  __$AppUserDtoCopyWithImpl(this._self, this._then);

  final _AppUserDto _self;
  final $Res Function(_AppUserDto) _then;

/// Create a copy of AppUserDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? email = null,Object? phone = null,Object? role = null,Object? isVerified = null,Object? createdAtMillis = null,}) {
  return _then(_AppUserDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,email: null == email ? _self.email : email // ignore: cast_nullable_to_non_nullable
as String,phone: null == phone ? _self.phone : phone // ignore: cast_nullable_to_non_nullable
as String,role: null == role ? _self.role : role // ignore: cast_nullable_to_non_nullable
as String,isVerified: null == isVerified ? _self.isVerified : isVerified // ignore: cast_nullable_to_non_nullable
as bool,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
