// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'referral_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_ReferralDto _$ReferralDtoFromJson(Map<String, dynamic> json) => _ReferralDto(
  id: json['id'] as String,
  code: json['code'] as String,
  referrerId: json['referrerId'] as String,
  referredUserId: json['referredUserId'] as String,
  referredName: json['referredName'] as String,
  createdAtMillis: (json['createdAtMillis'] as num).toInt(),
);

Map<String, dynamic> _$ReferralDtoToJson(_ReferralDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'code': instance.code,
      'referrerId': instance.referrerId,
      'referredUserId': instance.referredUserId,
      'referredName': instance.referredName,
      'createdAtMillis': instance.createdAtMillis,
    };
