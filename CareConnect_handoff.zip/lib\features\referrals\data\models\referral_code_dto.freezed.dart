// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'referral_code_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$ReferralCodeDto {

 String get code; String get ownerId; int get createdAtMillis;
/// Create a copy of ReferralCodeDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$ReferralCodeDtoCopyWith<ReferralCodeDto> get copyWith => _$ReferralCodeDtoCopyWithImpl<ReferralCodeDto>(this as ReferralCodeDto, _$identity);

  /// Serializes this ReferralCodeDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as ReferralCodeDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is ReferralCodeDto&&(identical(other.code, _this.code) || other.code == _this.code)&&(identical(other.ownerId, _this.ownerId) || other.ownerId == _this.ownerId)&&(identical(other.createdAtMillis, _this.createdAtMillis) || other.createdAtMillis == _this.createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as ReferralCodeDto;
  return Object.hash(runtimeType,_this.code,_this.ownerId,_this.createdAtMillis);
}

@override
String toString() {
  final _this = this as ReferralCodeDto;
  return 'ReferralCodeDto(code: ${_this.code}, ownerId: ${_this.ownerId}, createdAtMillis: ${_this.createdAtMillis})';
}


}

/// @nodoc
abstract mixin class $ReferralCodeDtoCopyWith<$Res>  {
  factory $ReferralCodeDtoCopyWith(ReferralCodeDto value, $Res Function(ReferralCodeDto) _then) = _$ReferralCodeDtoCopyWithImpl;
@useResult
$Res call({
 String code, String ownerId, int createdAtMillis
});




}
/// @nodoc
class _$ReferralCodeDtoCopyWithImpl<$Res>
    implements $ReferralCodeDtoCopyWith<$Res> {
  _$ReferralCodeDtoCopyWithImpl(this._self, this._then);

  final ReferralCodeDto _self;
  final $Res Function(ReferralCodeDto) _then;

/// Create a copy of ReferralCodeDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? code = null,Object? ownerId = null,Object? createdAtMillis = null,}) {
  return _then(ReferralCodeDto(
code: null == code ? _self.code : code // ignore: cast_nullable_to_non_nullable
as String,ownerId: null == ownerId ? _self.ownerId : ownerId // ignore: cast_nullable_to_non_nullable
as String,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [ReferralCodeDto].
extension ReferralCodeDtoPatterns on ReferralCodeDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _ReferralCodeDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _ReferralCodeDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _ReferralCodeDto value)  $default,){
final _that = this;
switch (_that) {
case _ReferralCodeDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _ReferralCodeDto value)?  $default,){
final _that = this;
switch (_that) {
case _ReferralCodeDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String code,  String ownerId,  int createdAtMillis)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _ReferralCodeDto() when $default != null:
return $default(_that.code,_that.ownerId,_that.createdAtMillis);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String code,  String ownerId,  int createdAtMillis)  $default,) {final _that = this;
switch (_that) {
case _ReferralCodeDto():
return $default(_that.code,_that.ownerId,_that.createdAtMillis);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String code,  String ownerId,  int createdAtMillis)?  $default,) {final _that = this;
switch (_that) {
case _ReferralCodeDto() when $default != null:
return $default(_that.code,_that.ownerId,_that.createdAtMillis);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _ReferralCodeDto extends ReferralCodeDto {
  const _ReferralCodeDto({required this.code, required this.ownerId, required this.createdAtMillis}): super._();
  factory _ReferralCodeDto.fromJson(Map<String, dynamic> json) => _$ReferralCodeDtoFromJson(json);

@override final  String code;
@override final  String ownerId;
@override final  int createdAtMillis;

/// Create a copy of ReferralCodeDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$ReferralCodeDtoCopyWith<_ReferralCodeDto> get copyWith => __$ReferralCodeDtoCopyWithImpl<_ReferralCodeDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$ReferralCodeDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _ReferralCodeDto&&(identical(other.code, code) || other.code == code)&&(identical(other.ownerId, ownerId) || other.ownerId == ownerId)&&(identical(other.createdAtMillis, createdAtMillis) || other.createdAtMillis == createdAtMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,code,ownerId,createdAtMillis);
}

@override
String toString() {
    return 'ReferralCodeDto(code: $code, ownerId: $ownerId, createdAtMillis: $createdAtMillis)';
}


}

/// @nodoc
abstract mixin class _$ReferralCodeDtoCopyWith<$Res> implements $ReferralCodeDtoCopyWith<$Res> {
  factory _$ReferralCodeDtoCopyWith(_ReferralCodeDto value, $Res Function(_ReferralCodeDto) _then) = __$ReferralCodeDtoCopyWithImpl;
@override @useResult
$Res call({
 String code, String ownerId, int createdAtMillis
});




}
/// @nodoc
class __$ReferralCodeDtoCopyWithImpl<$Res>
    implements _$ReferralCodeDtoCopyWith<$Res> {
  __$ReferralCodeDtoCopyWithImpl(this._self, this._then);

  final _ReferralCodeDto _self;
  final $Res Function(_ReferralCodeDto) _then;

/// Create a copy of ReferralCodeDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? code = null,Object? ownerId = null,Object? createdAtMillis = null,}) {
  return _then(_ReferralCodeDto(
code: null == code ? _self.code : code // ignore: cast_nullable_to_non_nullable
as String,ownerId: null == ownerId ? _self.ownerId : ownerId // ignore: cast_nullable_to_non_nullable
as String,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
