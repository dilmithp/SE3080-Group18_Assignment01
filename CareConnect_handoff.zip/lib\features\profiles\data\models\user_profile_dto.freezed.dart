// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'user_profile_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$UserProfileDto {

 String get userId; String get displayName; String? get photoUrl; String get bio; String get locality; double get latitude; double get longitude; List<String> get skillsOffered; List<String> get helpNeeded; List<Map<String, dynamic>> get availabilityWindows; Map<String, dynamic> get accessibilityPrefs; String? get emergencyContactName; String? get emergencyContactPhone; List<String> get languagesSpoken; List<String> get safetyPreferences;
/// Create a copy of UserProfileDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$UserProfileDtoCopyWith<UserProfileDto> get copyWith => _$UserProfileDtoCopyWithImpl<UserProfileDto>(this as UserProfileDto, _$identity);

  /// Serializes this UserProfileDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as UserProfileDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is UserProfileDto&&(identical(other.userId, _this.userId) || other.userId == _this.userId)&&(identical(other.displayName, _this.displayName) || other.displayName == _this.displayName)&&(identical(other.photoUrl, _this.photoUrl) || other.photoUrl == _this.photoUrl)&&(identical(other.bio, _this.bio) || other.bio == _this.bio)&&(identical(other.locality, _this.locality) || other.locality == _this.locality)&&(identical(other.latitude, _this.latitude) || other.latitude == _this.latitude)&&(identical(other.longitude, _this.longitude) || other.longitude == _this.longitude)&&const DeepCollectionEquality().equals(other.skillsOffered, _this.skillsOffered)&&const DeepCollectionEquality().equals(other.helpNeeded, _this.helpNeeded)&&const DeepCollectionEquality().equals(other.availabilityWindows, _this.availabilityWindows)&&const DeepCollectionEquality().equals(other.accessibilityPrefs, _this.accessibilityPrefs)&&(identical(other.emergencyContactName, _this.emergencyContactName) || other.emergencyContactName == _this.emergencyContactName)&&(identical(other.emergencyContactPhone, _this.emergencyContactPhone) || other.emergencyContactPhone == _this.emergencyContactPhone)&&const DeepCollectionEquality().equals(other.languagesSpoken, _this.languagesSpoken)&&const DeepCollectionEquality().equals(other.safetyPreferences, _this.safetyPreferences));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as UserProfileDto;
  return Object.hash(runtimeType,_this.userId,_this.displayName,_this.photoUrl,_this.bio,_this.locality,_this.latitude,_this.longitude,const DeepCollectionEquality().hash(_this.skillsOffered),const DeepCollectionEquality().hash(_this.helpNeeded),const DeepCollectionEquality().hash(_this.availabilityWindows),const DeepCollectionEquality().hash(_this.accessibilityPrefs),_this.emergencyContactName,_this.emergencyContactPhone,const DeepCollectionEquality().hash(_this.languagesSpoken),const DeepCollectionEquality().hash(_this.safetyPreferences));
}

@override
String toString() {
  final _this = this as UserProfileDto;
  return 'UserProfileDto(userId: ${_this.userId}, displayName: ${_this.displayName}, photoUrl: ${_this.photoUrl}, bio: ${_this.bio}, locality: ${_this.locality}, latitude: ${_this.latitude}, longitude: ${_this.longitude}, skillsOffered: ${_this.skillsOffered}, helpNeeded: ${_this.helpNeeded}, availabilityWindows: ${_this.availabilityWindows}, accessibilityPrefs: ${_this.accessibilityPrefs}, emergencyContactName: ${_this.emergencyContactName}, emergencyContactPhone: ${_this.emergencyContactPhone}, languagesSpoken: ${_this.languagesSpoken}, safetyPreferences: ${_this.safetyPreferences})';
}


}

/// @nodoc
abstract mixin class $UserProfileDtoCopyWith<$Res>  {
  factory $UserProfileDtoCopyWith(UserProfileDto value, $Res Function(UserProfileDto) _then) = _$UserProfileDtoCopyWithImpl;
@useResult
$Res call({
 String userId, String displayName, String? photoUrl, String bio, String locality, double latitude, double longitude, List<String> skillsOffered, List<String> helpNeeded, List<Map<String, dynamic>> availabilityWindows, Map<String, dynamic> accessibilityPrefs, String? emergencyContactName, String? emergencyContactPhone, List<String> languagesSpoken, List<String> safetyPreferences
});




}
/// @nodoc
class _$UserProfileDtoCopyWithImpl<$Res>
    implements $UserProfileDtoCopyWith<$Res> {
  _$UserProfileDtoCopyWithImpl(this._self, this._then);

  final UserProfileDto _self;
  final $Res Function(UserProfileDto) _then;

/// Create a copy of UserProfileDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? userId = null,Object? displayName = null,Object? photoUrl = freezed,Object? bio = null,Object? locality = null,Object? latitude = null,Object? longitude = null,Object? skillsOffered = null,Object? helpNeeded = null,Object? availabilityWindows = null,Object? accessibilityPrefs = null,Object? emergencyContactName = freezed,Object? emergencyContactPhone = freezed,Object? languagesSpoken = null,Object? safetyPreferences = null,}) {
  return _then(UserProfileDto(
userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,displayName: null == displayName ? _self.displayName : displayName // ignore: cast_nullable_to_non_nullable
as String,photoUrl: freezed == photoUrl ? _self.photoUrl : photoUrl // ignore: cast_nullable_to_non_nullable
as String?,bio: null == bio ? _self.bio : bio // ignore: cast_nullable_to_non_nullable
as String,locality: null == locality ? _self.locality : locality // ignore: cast_nullable_to_non_nullable
as String,latitude: null == latitude ? _self.latitude : latitude // ignore: cast_nullable_to_non_nullable
as double,longitude: null == longitude ? _self.longitude : longitude // ignore: cast_nullable_to_non_nullable
as double,skillsOffered: null == skillsOffered ? _self.skillsOffered : skillsOffered // ignore: cast_nullable_to_non_nullable
as List<String>,helpNeeded: null == helpNeeded ? _self.helpNeeded : helpNeeded // ignore: cast_nullable_to_non_nullable
as List<String>,availabilityWindows: null == availabilityWindows ? _self.availabilityWindows : availabilityWindows // ignore: cast_nullable_to_non_nullable
as List<Map<String, dynamic>>,accessibilityPrefs: null == accessibilityPrefs ? _self.accessibilityPrefs : accessibilityPrefs // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>,emergencyContactName: freezed == emergencyContactName ? _self.emergencyContactName : emergencyContactName // ignore: cast_nullable_to_non_nullable
as String?,emergencyContactPhone: freezed == emergencyContactPhone ? _self.emergencyContactPhone : emergencyContactPhone // ignore: cast_nullable_to_non_nullable
as String?,languagesSpoken: null == languagesSpoken ? _self.languagesSpoken : languagesSpoken // ignore: cast_nullable_to_non_nullable
as List<String>,safetyPreferences: null == safetyPreferences ? _self.safetyPreferences : safetyPreferences // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}

}


/// Adds pattern-matching-related methods to [UserProfileDto].
extension UserProfileDtoPatterns on UserProfileDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _UserProfileDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _UserProfileDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _UserProfileDto value)  $default,){
final _that = this;
switch (_that) {
case _UserProfileDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _UserProfileDto value)?  $default,){
final _that = this;
switch (_that) {
case _UserProfileDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String userId,  String displayName,  String? photoUrl,  String bio,  String locality,  double latitude,  double longitude,  List<String> skillsOffered,  List<String> helpNeeded,  List<Map<String, dynamic>> availabilityWindows,  Map<String, dynamic> accessibilityPrefs,  String? emergencyContactName,  String? emergencyContactPhone,  List<String> languagesSpoken,  List<String> safetyPreferences)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _UserProfileDto() when $default != null:
return $default(_that.userId,_that.displayName,_that.photoUrl,_that.bio,_that.locality,_that.latitude,_that.longitude,_that.skillsOffered,_that.helpNeeded,_that.availabilityWindows,_that.accessibilityPrefs,_that.emergencyContactName,_that.emergencyContactPhone,_that.languagesSpoken,_that.safetyPreferences);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String userId,  String displayName,  String? photoUrl,  String bio,  String locality,  double latitude,  double longitude,  List<String> skillsOffered,  List<String> helpNeeded,  List<Map<String, dynamic>> availabilityWindows,  Map<String, dynamic> accessibilityPrefs,  String? emergencyContactName,  String? emergencyContactPhone,  List<String> languagesSpoken,  List<String> safetyPreferences)  $default,) {final _that = this;
switch (_that) {
case _UserProfileDto():
return $default(_that.userId,_that.displayName,_that.photoUrl,_that.bio,_that.locality,_that.latitude,_that.longitude,_that.skillsOffered,_that.helpNeeded,_that.availabilityWindows,_that.accessibilityPrefs,_that.emergencyContactName,_that.emergencyContactPhone,_that.languagesSpoken,_that.safetyPreferences);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String userId,  String displayName,  String? photoUrl,  String bio,  String locality,  double latitude,  double longitude,  List<String> skillsOffered,  List<String> helpNeeded,  List<Map<String, dynamic>> availabilityWindows,  Map<String, dynamic> accessibilityPrefs,  String? emergencyContactName,  String? emergencyContactPhone,  List<String> languagesSpoken,  List<String> safetyPreferences)?  $default,) {final _that = this;
switch (_that) {
case _UserProfileDto() when $default != null:
return $default(_that.userId,_that.displayName,_that.photoUrl,_that.bio,_that.locality,_that.latitude,_that.longitude,_that.skillsOffered,_that.helpNeeded,_that.availabilityWindows,_that.accessibilityPrefs,_that.emergencyContactName,_that.emergencyContactPhone,_that.languagesSpoken,_that.safetyPreferences);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _UserProfileDto extends UserProfileDto {
  const _UserProfileDto({required this.userId, required this.displayName, this.photoUrl, required this.bio, required this.locality, required this.latitude, required this.longitude, required  List<String> skillsOffered, required  List<String> helpNeeded, required  List<Map<String, dynamic>> availabilityWindows, required  Map<String, dynamic> accessibilityPrefs, this.emergencyContactName, this.emergencyContactPhone,  List<String> languagesSpoken = const <String>[],  List<String> safetyPreferences = const <String>[]}): _skillsOffered = skillsOffered,_helpNeeded = helpNeeded,_availabilityWindows = availabilityWindows,_accessibilityPrefs = accessibilityPrefs,_languagesSpoken = languagesSpoken,_safetyPreferences = safetyPreferences,super._();
  factory _UserProfileDto.fromJson(Map<String, dynamic> json) => _$UserProfileDtoFromJson(json);

@override final  String userId;
@override final  String displayName;
@override final  String? photoUrl;
@override final  String bio;
@override final  String locality;
@override final  double latitude;
@override final  double longitude;
 final  List<String> _skillsOffered;
@override List<String> get skillsOffered {
  if (_skillsOffered is EqualUnmodifiableListView) return _skillsOffered;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_skillsOffered);
}

 final  List<String> _helpNeeded;
@override List<String> get helpNeeded {
  if (_helpNeeded is EqualUnmodifiableListView) return _helpNeeded;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_helpNeeded);
}

 final  List<Map<String, dynamic>> _availabilityWindows;
@override List<Map<String, dynamic>> get availabilityWindows {
  if (_availabilityWindows is EqualUnmodifiableListView) return _availabilityWindows;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_availabilityWindows);
}

 final  Map<String, dynamic> _accessibilityPrefs;
@override Map<String, dynamic> get accessibilityPrefs {
  if (_accessibilityPrefs is EqualUnmodifiableMapView) return _accessibilityPrefs;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableMapView(_accessibilityPrefs);
}

@override final  String? emergencyContactName;
@override final  String? emergencyContactPhone;
 final  List<String> _languagesSpoken;
@override@JsonKey() List<String> get languagesSpoken {
  if (_languagesSpoken is EqualUnmodifiableListView) return _languagesSpoken;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_languagesSpoken);
}

 final  List<String> _safetyPreferences;
@override@JsonKey() List<String> get safetyPreferences {
  if (_safetyPreferences is EqualUnmodifiableListView) return _safetyPreferences;
  // ignore: implicit_dynamic_type
  return EqualUnmodifiableListView(_safetyPreferences);
}


/// Create a copy of UserProfileDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$UserProfileDtoCopyWith<_UserProfileDto> get copyWith => __$UserProfileDtoCopyWithImpl<_UserProfileDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$UserProfileDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _UserProfileDto&&(identical(other.userId, userId) || other.userId == userId)&&(identical(other.displayName, displayName) || other.displayName == displayName)&&(identical(other.photoUrl, photoUrl) || other.photoUrl == photoUrl)&&(identical(other.bio, bio) || other.bio == bio)&&(identical(other.locality, locality) || other.locality == locality)&&(identical(other.latitude, latitude) || other.latitude == latitude)&&(identical(other.longitude, longitude) || other.longitude == longitude)&&const DeepCollectionEquality().equals(other.skillsOffered, _skillsOffered)&&const DeepCollectionEquality().equals(other.helpNeeded, _helpNeeded)&&const DeepCollectionEquality().equals(other.availabilityWindows, _availabilityWindows)&&const DeepCollectionEquality().equals(other.accessibilityPrefs, _accessibilityPrefs)&&(identical(other.emergencyContactName, emergencyContactName) || other.emergencyContactName == emergencyContactName)&&(identical(other.emergencyContactPhone, emergencyContactPhone) || other.emergencyContactPhone == emergencyContactPhone)&&const DeepCollectionEquality().equals(other.languagesSpoken, _languagesSpoken)&&const DeepCollectionEquality().equals(other.safetyPreferences, _safetyPreferences));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,userId,displayName,photoUrl,bio,locality,latitude,longitude,const DeepCollectionEquality().hash(_skillsOffered),const DeepCollectionEquality().hash(_helpNeeded),const DeepCollectionEquality().hash(_availabilityWindows),const DeepCollectionEquality().hash(_accessibilityPrefs),emergencyContactName,emergencyContactPhone,const DeepCollectionEquality().hash(_languagesSpoken),const DeepCollectionEquality().hash(_safetyPreferences));
}

@override
String toString() {
    return 'UserProfileDto(userId: $userId, displayName: $displayName, photoUrl: $photoUrl, bio: $bio, locality: $locality, latitude: $latitude, longitude: $longitude, skillsOffered: $skillsOffered, helpNeeded: $helpNeeded, availabilityWindows: $availabilityWindows, accessibilityPrefs: $accessibilityPrefs, emergencyContactName: $emergencyContactName, emergencyContactPhone: $emergencyContactPhone, languagesSpoken: $languagesSpoken, safetyPreferences: $safetyPreferences)';
}


}

/// @nodoc
abstract mixin class _$UserProfileDtoCopyWith<$Res> implements $UserProfileDtoCopyWith<$Res> {
  factory _$UserProfileDtoCopyWith(_UserProfileDto value, $Res Function(_UserProfileDto) _then) = __$UserProfileDtoCopyWithImpl;
@override @useResult
$Res call({
 String userId, String displayName, String? photoUrl, String bio, String locality, double latitude, double longitude, List<String> skillsOffered, List<String> helpNeeded, List<Map<String, dynamic>> availabilityWindows, Map<String, dynamic> accessibilityPrefs, String? emergencyContactName, String? emergencyContactPhone, List<String> languagesSpoken, List<String> safetyPreferences
});




}
/// @nodoc
class __$UserProfileDtoCopyWithImpl<$Res>
    implements _$UserProfileDtoCopyWith<$Res> {
  __$UserProfileDtoCopyWithImpl(this._self, this._then);

  final _UserProfileDto _self;
  final $Res Function(_UserProfileDto) _then;

/// Create a copy of UserProfileDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? userId = null,Object? displayName = null,Object? photoUrl = freezed,Object? bio = null,Object? locality = null,Object? latitude = null,Object? longitude = null,Object? skillsOffered = null,Object? helpNeeded = null,Object? availabilityWindows = null,Object? accessibilityPrefs = null,Object? emergencyContactName = freezed,Object? emergencyContactPhone = freezed,Object? languagesSpoken = null,Object? safetyPreferences = null,}) {
  return _then(_UserProfileDto(
userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,displayName: null == displayName ? _self.displayName : displayName // ignore: cast_nullable_to_non_nullable
as String,photoUrl: freezed == photoUrl ? _self.photoUrl : photoUrl // ignore: cast_nullable_to_non_nullable
as String?,bio: null == bio ? _self.bio : bio // ignore: cast_nullable_to_non_nullable
as String,locality: null == locality ? _self.locality : locality // ignore: cast_nullable_to_non_nullable
as String,latitude: null == latitude ? _self.latitude : latitude // ignore: cast_nullable_to_non_nullable
as double,longitude: null == longitude ? _self.longitude : longitude // ignore: cast_nullable_to_non_nullable
as double,skillsOffered: null == skillsOffered ? _self._skillsOffered : skillsOffered // ignore: cast_nullable_to_non_nullable
as List<String>,helpNeeded: null == helpNeeded ? _self._helpNeeded : helpNeeded // ignore: cast_nullable_to_non_nullable
as List<String>,availabilityWindows: null == availabilityWindows ? _self._availabilityWindows : availabilityWindows // ignore: cast_nullable_to_non_nullable
as List<Map<String, dynamic>>,accessibilityPrefs: null == accessibilityPrefs ? _self._accessibilityPrefs : accessibilityPrefs // ignore: cast_nullable_to_non_nullable
as Map<String, dynamic>,emergencyContactName: freezed == emergencyContactName ? _self.emergencyContactName : emergencyContactName // ignore: cast_nullable_to_non_nullable
as String?,emergencyContactPhone: freezed == emergencyContactPhone ? _self.emergencyContactPhone : emergencyContactPhone // ignore: cast_nullable_to_non_nullable
as String?,languagesSpoken: null == languagesSpoken ? _self._languagesSpoken : languagesSpoken // ignore: cast_nullable_to_non_nullable
as List<String>,safetyPreferences: null == safetyPreferences ? _self._safetyPreferences : safetyPreferences // ignore: cast_nullable_to_non_nullable
as List<String>,
  ));
}


}

// dart format on
