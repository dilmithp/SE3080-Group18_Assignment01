// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'trust_score_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$TrustScoreDto {

 String get userId; double get score; int get completedSessions; double get averageRating; int get lastUpdatedMillis;
/// Create a copy of TrustScoreDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$TrustScoreDtoCopyWith<TrustScoreDto> get copyWith => _$TrustScoreDtoCopyWithImpl<TrustScoreDto>(this as TrustScoreDto, _$identity);

  /// Serializes this TrustScoreDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as TrustScoreDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is TrustScoreDto&&(identical(other.userId, _this.userId) || other.userId == _this.userId)&&(identical(other.score, _this.score) || other.score == _this.score)&&(identical(other.completedSessions, _this.completedSessions) || other.completedSessions == _this.completedSessions)&&(identical(other.averageRating, _this.averageRating) || other.averageRating == _this.averageRating)&&(identical(other.lastUpdatedMillis, _this.lastUpdatedMillis) || other.lastUpdatedMillis == _this.lastUpdatedMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as TrustScoreDto;
  return Object.hash(runtimeType,_this.userId,_this.score,_this.completedSessions,_this.averageRating,_this.lastUpdatedMillis);
}

@override
String toString() {
  final _this = this as TrustScoreDto;
  return 'TrustScoreDto(userId: ${_this.userId}, score: ${_this.score}, completedSessions: ${_this.completedSessions}, averageRating: ${_this.averageRating}, lastUpdatedMillis: ${_this.lastUpdatedMillis})';
}


}

/// @nodoc
abstract mixin class $TrustScoreDtoCopyWith<$Res>  {
  factory $TrustScoreDtoCopyWith(TrustScoreDto value, $Res Function(TrustScoreDto) _then) = _$TrustScoreDtoCopyWithImpl;
@useResult
$Res call({
 String userId, double score, int completedSessions, double averageRating, int lastUpdatedMillis
});




}
/// @nodoc
class _$TrustScoreDtoCopyWithImpl<$Res>
    implements $TrustScoreDtoCopyWith<$Res> {
  _$TrustScoreDtoCopyWithImpl(this._self, this._then);

  final TrustScoreDto _self;
  final $Res Function(TrustScoreDto) _then;

/// Create a copy of TrustScoreDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? userId = null,Object? score = null,Object? completedSessions = null,Object? averageRating = null,Object? lastUpdatedMillis = null,}) {
  return _then(TrustScoreDto(
userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,score: null == score ? _self.score : score // ignore: cast_nullable_to_non_nullable
as double,completedSessions: null == completedSessions ? _self.completedSessions : completedSessions // ignore: cast_nullable_to_non_nullable
as int,averageRating: null == averageRating ? _self.averageRating : averageRating // ignore: cast_nullable_to_non_nullable
as double,lastUpdatedMillis: null == lastUpdatedMillis ? _self.lastUpdatedMillis : lastUpdatedMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}

}


/// Adds pattern-matching-related methods to [TrustScoreDto].
extension TrustScoreDtoPatterns on TrustScoreDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _TrustScoreDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _TrustScoreDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _TrustScoreDto value)  $default,){
final _that = this;
switch (_that) {
case _TrustScoreDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _TrustScoreDto value)?  $default,){
final _that = this;
switch (_that) {
case _TrustScoreDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String userId,  double score,  int completedSessions,  double averageRating,  int lastUpdatedMillis)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _TrustScoreDto() when $default != null:
return $default(_that.userId,_that.score,_that.completedSessions,_that.averageRating,_that.lastUpdatedMillis);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String userId,  double score,  int completedSessions,  double averageRating,  int lastUpdatedMillis)  $default,) {final _that = this;
switch (_that) {
case _TrustScoreDto():
return $default(_that.userId,_that.score,_that.completedSessions,_that.averageRating,_that.lastUpdatedMillis);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String userId,  double score,  int completedSessions,  double averageRating,  int lastUpdatedMillis)?  $default,) {final _that = this;
switch (_that) {
case _TrustScoreDto() when $default != null:
return $default(_that.userId,_that.score,_that.completedSessions,_that.averageRating,_that.lastUpdatedMillis);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _TrustScoreDto extends TrustScoreDto {
  const _TrustScoreDto({required this.userId, required this.score, required this.completedSessions, required this.averageRating, required this.lastUpdatedMillis}): super._();
  factory _TrustScoreDto.fromJson(Map<String, dynamic> json) => _$TrustScoreDtoFromJson(json);

@override final  String userId;
@override final  double score;
@override final  int completedSessions;
@override final  double averageRating;
@override final  int lastUpdatedMillis;

/// Create a copy of TrustScoreDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$TrustScoreDtoCopyWith<_TrustScoreDto> get copyWith => __$TrustScoreDtoCopyWithImpl<_TrustScoreDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$TrustScoreDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _TrustScoreDto&&(identical(other.userId, userId) || other.userId == userId)&&(identical(other.score, score) || other.score == score)&&(identical(other.completedSessions, completedSessions) || other.completedSessions == completedSessions)&&(identical(other.averageRating, averageRating) || other.averageRating == averageRating)&&(identical(other.lastUpdatedMillis, lastUpdatedMillis) || other.lastUpdatedMillis == lastUpdatedMillis));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,userId,score,completedSessions,averageRating,lastUpdatedMillis);
}

@override
String toString() {
    return 'TrustScoreDto(userId: $userId, score: $score, completedSessions: $completedSessions, averageRating: $averageRating, lastUpdatedMillis: $lastUpdatedMillis)';
}


}

/// @nodoc
abstract mixin class _$TrustScoreDtoCopyWith<$Res> implements $TrustScoreDtoCopyWith<$Res> {
  factory _$TrustScoreDtoCopyWith(_TrustScoreDto value, $Res Function(_TrustScoreDto) _then) = __$TrustScoreDtoCopyWithImpl;
@override @useResult
$Res call({
 String userId, double score, int completedSessions, double averageRating, int lastUpdatedMillis
});




}
/// @nodoc
class __$TrustScoreDtoCopyWithImpl<$Res>
    implements _$TrustScoreDtoCopyWith<$Res> {
  __$TrustScoreDtoCopyWithImpl(this._self, this._then);

  final _TrustScoreDto _self;
  final $Res Function(_TrustScoreDto) _then;

/// Create a copy of TrustScoreDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? userId = null,Object? score = null,Object? completedSessions = null,Object? averageRating = null,Object? lastUpdatedMillis = null,}) {
  return _then(_TrustScoreDto(
userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,score: null == score ? _self.score : score // ignore: cast_nullable_to_non_nullable
as double,completedSessions: null == completedSessions ? _self.completedSessions : completedSessions // ignore: cast_nullable_to_non_nullable
as int,averageRating: null == averageRating ? _self.averageRating : averageRating // ignore: cast_nullable_to_non_nullable
as double,lastUpdatedMillis: null == lastUpdatedMillis ? _self.lastUpdatedMillis : lastUpdatedMillis // ignore: cast_nullable_to_non_nullable
as int,
  ));
}


}

// dart format on
