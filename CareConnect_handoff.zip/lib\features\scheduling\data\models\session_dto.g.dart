// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'session_dto.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

_SessionDto _$SessionDtoFromJson(Map<String, dynamic> json) => _SessionDto(
  id: json['id'] as String,
  requesterId: json['requesterId'] as String,
  volunteerId: json['volunteerId'] as String,
  scheduledAtMillis: (json['scheduledAtMillis'] as num).toInt(),
  durationMinutes: (json['durationMinutes'] as num).toInt(),
  status: json['status'] as String,
  location: json['location'] as String,
  notes: json['notes'] as String?,
  isRecurring: json['isRecurring'] as bool? ?? false,
  recurrenceRule: json['recurrenceRule'] as String?,
  checkInAtMillis: (json['checkInAtMillis'] as num?)?.toInt(),
  checkOutAtMillis: (json['checkOutAtMillis'] as num?)?.toInt(),
  conflictFlag: json['conflictFlag'] as bool? ?? false,
  seriesId: json['seriesId'] as String?,
  createdAtMillis: (json['createdAtMillis'] as num?)?.toInt(),
  updatedAtMillis: (json['updatedAtMillis'] as num?)?.toInt(),
);

Map<String, dynamic> _$SessionDtoToJson(_SessionDto instance) =>
    <String, dynamic>{
      'id': instance.id,
      'requesterId': instance.requesterId,
      'volunteerId': instance.volunteerId,
      'scheduledAtMillis': instance.scheduledAtMillis,
      'durationMinutes': instance.durationMinutes,
      'status': instance.status,
      'location': instance.location,
      'notes': instance.notes,
      'isRecurring': instance.isRecurring,
      'recurrenceRule': instance.recurrenceRule,
      'checkInAtMillis': instance.checkInAtMillis,
      'checkOutAtMillis': instance.checkOutAtMillis,
      'conflictFlag': instance.conflictFlag,
      'seriesId': instance.seriesId,
      'createdAtMillis': instance.createdAtMillis,
      'updatedAtMillis': instance.updatedAtMillis,
    };
