// GENERATED CODE - DO NOT MODIFY BY HAND
// coverage:ignore-file
// ignore_for_file: type=lint, type=warning, deprecated_member_use, deprecated_member_use_from_same_package
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'app_notification_dto.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// dart format off
T _$identity<T>(T value) => value;

/// @nodoc
mixin _$AppNotificationDto {

 String get id; String get userId; String get type; String get title; String get body; bool get isRead; int get createdAtMillis; String? get relatedId;
/// Create a copy of AppNotificationDto
/// with the given fields replaced by the non-null parameter values.
@JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
$AppNotificationDtoCopyWith<AppNotificationDto> get copyWith => _$AppNotificationDtoCopyWithImpl<AppNotificationDto>(this as AppNotificationDto, _$identity);

  /// Serializes this AppNotificationDto to a JSON map.
  Map<String, dynamic> toJson();


@override
bool operator ==(Object other) {
  final _this = this as AppNotificationDto;
  return identical(this, other) || (other.runtimeType == runtimeType&&other is AppNotificationDto&&(identical(other.id, _this.id) || other.id == _this.id)&&(identical(other.userId, _this.userId) || other.userId == _this.userId)&&(identical(other.type, _this.type) || other.type == _this.type)&&(identical(other.title, _this.title) || other.title == _this.title)&&(identical(other.body, _this.body) || other.body == _this.body)&&(identical(other.isRead, _this.isRead) || other.isRead == _this.isRead)&&(identical(other.createdAtMillis, _this.createdAtMillis) || other.createdAtMillis == _this.createdAtMillis)&&(identical(other.relatedId, _this.relatedId) || other.relatedId == _this.relatedId));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
  final _this = this as AppNotificationDto;
  return Object.hash(runtimeType,_this.id,_this.userId,_this.type,_this.title,_this.body,_this.isRead,_this.createdAtMillis,_this.relatedId);
}

@override
String toString() {
  final _this = this as AppNotificationDto;
  return 'AppNotificationDto(id: ${_this.id}, userId: ${_this.userId}, type: ${_this.type}, title: ${_this.title}, body: ${_this.body}, isRead: ${_this.isRead}, createdAtMillis: ${_this.createdAtMillis}, relatedId: ${_this.relatedId})';
}


}

/// @nodoc
abstract mixin class $AppNotificationDtoCopyWith<$Res>  {
  factory $AppNotificationDtoCopyWith(AppNotificationDto value, $Res Function(AppNotificationDto) _then) = _$AppNotificationDtoCopyWithImpl;
@useResult
$Res call({
 String id, String userId, String type, String title, String body, bool isRead, int createdAtMillis, String? relatedId
});




}
/// @nodoc
class _$AppNotificationDtoCopyWithImpl<$Res>
    implements $AppNotificationDtoCopyWith<$Res> {
  _$AppNotificationDtoCopyWithImpl(this._self, this._then);

  final AppNotificationDto _self;
  final $Res Function(AppNotificationDto) _then;

/// Create a copy of AppNotificationDto
/// with the given fields replaced by the non-null parameter values.
@pragma('vm:prefer-inline') @override $Res call({Object? id = null,Object? userId = null,Object? type = null,Object? title = null,Object? body = null,Object? isRead = null,Object? createdAtMillis = null,Object? relatedId = freezed,}) {
  return _then(AppNotificationDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as String,title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,body: null == body ? _self.body : body // ignore: cast_nullable_to_non_nullable
as String,isRead: null == isRead ? _self.isRead : isRead // ignore: cast_nullable_to_non_nullable
as bool,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,relatedId: freezed == relatedId ? _self.relatedId : relatedId // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}

}


/// Adds pattern-matching-related methods to [AppNotificationDto].
extension AppNotificationDtoPatterns on AppNotificationDto {
/// A variant of `map` that fallback to returning `orElse`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeMap<TResult extends Object?>(TResult Function( _AppNotificationDto value)?  $default,{required TResult orElse(),}){
final _that = this;
switch (_that) {
case _AppNotificationDto() when $default != null:
return $default(_that);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// Callbacks receives the raw object, upcasted.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case final Subclass2 value:
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult map<TResult extends Object?>(TResult Function( _AppNotificationDto value)  $default,){
final _that = this;
switch (_that) {
case _AppNotificationDto():
return $default(_that);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `map` that fallback to returning `null`.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case final Subclass value:
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? mapOrNull<TResult extends Object?>(TResult? Function( _AppNotificationDto value)?  $default,){
final _that = this;
switch (_that) {
case _AppNotificationDto() when $default != null:
return $default(_that);case _:
  return null;

}
}
/// A variant of `when` that fallback to an `orElse` callback.
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return orElse();
/// }
/// ```

@optionalTypeArgs TResult maybeWhen<TResult extends Object?>(TResult Function( String id,  String userId,  String type,  String title,  String body,  bool isRead,  int createdAtMillis,  String? relatedId)?  $default,{required TResult orElse(),}) {final _that = this;
switch (_that) {
case _AppNotificationDto() when $default != null:
return $default(_that.id,_that.userId,_that.type,_that.title,_that.body,_that.isRead,_that.createdAtMillis,_that.relatedId);case _:
  return orElse();

}
}
/// A `switch`-like method, using callbacks.
///
/// As opposed to `map`, this offers destructuring.
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case Subclass2(:final field2):
///     return ...;
/// }
/// ```

@optionalTypeArgs TResult when<TResult extends Object?>(TResult Function( String id,  String userId,  String type,  String title,  String body,  bool isRead,  int createdAtMillis,  String? relatedId)  $default,) {final _that = this;
switch (_that) {
case _AppNotificationDto():
return $default(_that.id,_that.userId,_that.type,_that.title,_that.body,_that.isRead,_that.createdAtMillis,_that.relatedId);case _:
  throw StateError('Unexpected subclass');

}
}
/// A variant of `when` that fallback to returning `null`
///
/// It is equivalent to doing:
/// ```dart
/// switch (sealedClass) {
///   case Subclass(:final field):
///     return ...;
///   case _:
///     return null;
/// }
/// ```

@optionalTypeArgs TResult? whenOrNull<TResult extends Object?>(TResult? Function( String id,  String userId,  String type,  String title,  String body,  bool isRead,  int createdAtMillis,  String? relatedId)?  $default,) {final _that = this;
switch (_that) {
case _AppNotificationDto() when $default != null:
return $default(_that.id,_that.userId,_that.type,_that.title,_that.body,_that.isRead,_that.createdAtMillis,_that.relatedId);case _:
  return null;

}
}

}

/// @nodoc
@JsonSerializable()

class _AppNotificationDto extends AppNotificationDto {
  const _AppNotificationDto({required this.id, required this.userId, required this.type, required this.title, required this.body, required this.isRead, required this.createdAtMillis, this.relatedId}): super._();
  factory _AppNotificationDto.fromJson(Map<String, dynamic> json) => _$AppNotificationDtoFromJson(json);

@override final  String id;
@override final  String userId;
@override final  String type;
@override final  String title;
@override final  String body;
@override final  bool isRead;
@override final  int createdAtMillis;
@override final  String? relatedId;

/// Create a copy of AppNotificationDto
/// with the given fields replaced by the non-null parameter values.
@override @JsonKey(includeFromJson: false, includeToJson: false)
@pragma('vm:prefer-inline')
_$AppNotificationDtoCopyWith<_AppNotificationDto> get copyWith => __$AppNotificationDtoCopyWithImpl<_AppNotificationDto>(this, _$identity);

@override
Map<String, dynamic> toJson() {
  return _$AppNotificationDtoToJson(this, );
}

@override
bool operator ==(Object other) {
    return identical(this, other) || (other.runtimeType == runtimeType&&other is _AppNotificationDto&&(identical(other.id, id) || other.id == id)&&(identical(other.userId, userId) || other.userId == userId)&&(identical(other.type, type) || other.type == type)&&(identical(other.title, title) || other.title == title)&&(identical(other.body, body) || other.body == body)&&(identical(other.isRead, isRead) || other.isRead == isRead)&&(identical(other.createdAtMillis, createdAtMillis) || other.createdAtMillis == createdAtMillis)&&(identical(other.relatedId, relatedId) || other.relatedId == relatedId));
}

@JsonKey(includeFromJson: false, includeToJson: false)
@override
int get hashCode {
    return Object.hash(runtimeType,id,userId,type,title,body,isRead,createdAtMillis,relatedId);
}

@override
String toString() {
    return 'AppNotificationDto(id: $id, userId: $userId, type: $type, title: $title, body: $body, isRead: $isRead, createdAtMillis: $createdAtMillis, relatedId: $relatedId)';
}


}

/// @nodoc
abstract mixin class _$AppNotificationDtoCopyWith<$Res> implements $AppNotificationDtoCopyWith<$Res> {
  factory _$AppNotificationDtoCopyWith(_AppNotificationDto value, $Res Function(_AppNotificationDto) _then) = __$AppNotificationDtoCopyWithImpl;
@override @useResult
$Res call({
 String id, String userId, String type, String title, String body, bool isRead, int createdAtMillis, String? relatedId
});




}
/// @nodoc
class __$AppNotificationDtoCopyWithImpl<$Res>
    implements _$AppNotificationDtoCopyWith<$Res> {
  __$AppNotificationDtoCopyWithImpl(this._self, this._then);

  final _AppNotificationDto _self;
  final $Res Function(_AppNotificationDto) _then;

/// Create a copy of AppNotificationDto
/// with the given fields replaced by the non-null parameter values.
@override @pragma('vm:prefer-inline') $Res call({Object? id = null,Object? userId = null,Object? type = null,Object? title = null,Object? body = null,Object? isRead = null,Object? createdAtMillis = null,Object? relatedId = freezed,}) {
  return _then(_AppNotificationDto(
id: null == id ? _self.id : id // ignore: cast_nullable_to_non_nullable
as String,userId: null == userId ? _self.userId : userId // ignore: cast_nullable_to_non_nullable
as String,type: null == type ? _self.type : type // ignore: cast_nullable_to_non_nullable
as String,title: null == title ? _self.title : title // ignore: cast_nullable_to_non_nullable
as String,body: null == body ? _self.body : body // ignore: cast_nullable_to_non_nullable
as String,isRead: null == isRead ? _self.isRead : isRead // ignore: cast_nullable_to_non_nullable
as bool,createdAtMillis: null == createdAtMillis ? _self.createdAtMillis : createdAtMillis // ignore: cast_nullable_to_non_nullable
as int,relatedId: freezed == relatedId ? _self.relatedId : relatedId // ignore: cast_nullable_to_non_nullable
as String?,
  ));
}


}

// dart format on
