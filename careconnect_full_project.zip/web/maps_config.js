// Local-only Google Maps Web API key — see maps_config.js.example.
// This file is gitignored on purpose: never commit a real API key.
window.GOOGLE_MAPS_API_KEY = "AIzaSyD47bqVOosy1ZduND5o7Kwej7TABLnmYMA";
